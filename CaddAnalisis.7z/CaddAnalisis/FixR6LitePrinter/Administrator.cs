﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CADD_ANALISIS;


namespace FixR6LitePrinter
{
    public partial class Administrator : Form
    {

        public event loginHandler Login;
        public delegate void loginHandler(object source, loginArgs e);


        public class loginArgs : EventArgs
        {
            private string mensaje;
            public loginArgs(string Text)
            {
                mensaje = Text;
            }
            public string GetInfo()
            {
                return mensaje;
            }
        }

        ClassLogin classLogin = new ClassLogin();

        public Administrator()
        {
            InitializeComponent();
            txtUser.Text = "Adminitrator";
            this.Opacity = .9;
           
        }


        void Evento(object obj, loginArgs x)
        {
            string mensaje = x.GetInfo();
           // if (mensaje.Contains("OK")) MessageBox.Show(mensaje);
        }




        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                ///////////////////////////////CREDENCIALES DE WINDOWS///////////////////////////////
                //Login += Evento;
                //loginArgs ev = new loginArgs("OK" + txtUser.Text);
                //bool result = classLogin.Logon(txtUser.Text, txtPassword.Text);
                //if (result)
                //{
                //    txtUser.Text = "";
                //    txtUser.Text = "";
                //    Login(null, ev);
                //    this.Hide();
                //    Application.Restart();

                //}
                //else
                //{
                //    MessageBox.Show("Datos Incorrectos");
                //}
                //////////////////////////////////////////////////////////////////////////////////////
                ///

               

                if(txtUser.Text == "Adminitrator" && txtPassword.Text == "123")
                {
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Datos incorrectos");
                }

            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox1_DoubleClick(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}

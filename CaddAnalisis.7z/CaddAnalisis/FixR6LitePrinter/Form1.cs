﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.ServiceProcess;
using Microsoft.VisualBasic;
using GetSerialClassMC;
using AutoIt;
using System.Media;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.Sockets;

/// <summary>
/// VERSION 1.0.1.6
/// V#5#1#3#0#9#8#8#
/// 
/// CADD-ANALISIS 
/// developer: JAVIER MARQUEZ
/// 
/// Cobertura 
/// 
/// 7358 
/// IOBOARD.........................................................1.0.0.1
/// UPS.............................................................1.0.0.1
/// PRINTER-CHECKHEALTH-SERVICIO NCRLOADER..........................1.0.0.1
/// SCALE-CHECKHEALTH...............................................1.0.0.1
/// BCR MONEYCONTROL-CHECKHEALTH....................................1.0.0.1
/// GSR50-CHECKHEALTH ..............................................1.0.0.1
/// USBCHECKER......................................................1.0.0.4
/// BCR MONEYCONTROL SENSORIAC......................................1.0.0.5
/// 
/// 
/// 
/// 
/// 
/// 7360                                                           
/// IOBOARD.........................................................1.0.0.1
/// UPS.............................................................1.0.0.1
/// SCALE-CHECKHEALTH...............................................1.0.0.1
/// CRANE-CHECKHEALTH...............................................1.0.0.1
/// GSR50-CHECKHEALTH...............................................1.0.0.1
/// PRINTER-CHECKHEALTH-SERVICIO NCRLOADER..........................1.0.0.1
/// USBCHECKER......................................................1.0.0.5
/// PRINTER GETPRINTER INFO.........................................1.0.0.9
/// 
/// 7350R5
/// 
/// 
/// 
/// 
/// 7350R6Lite
/// USBCHECKER.....................................................1.0.0.6
/// SCALE CHECKHEALTH..............................................1.0.0.7
/// PRINTER REC....................................................1.0.0.8
/// BCR CHECKHEALTH................................................1.0.1.0
/// IOBOARD........................................................1.0.1.0
/// PRINTER CHECK SERIAL, MAIN, FIRMWARE NUMBER....................1.0.1.1
/// 
/// 
/// 
/// 
/// 
/// 
/// BUGS
/// FIX StreamClose en cada prueba...............................................1.0.0.1
/// FIX Monitoreo de servicio NCRLOADER..........................................1.0.0.1
/// ADD CAD-RERUN................................................................1.0.0.2
/// ADD COVERANGE TO COIN ACCEPTOR DISCONNECTED BCR MONEY CONTROL................1.0.0.X /// VALIDAR NO FUNCIONO SE DEVUELVE A VERSION ANTERIOR
/// ADD OPEN APPLICATION WITH INPUT ARGS.........................................1.0.0.3
/// ADD COVERANGE TO USBCHECKER..................................................1.0.0.4
/// ADD COVERANGE TO BCR MONEY CONTROL SENSORINAC................................1.0.0.5
/// ADD COVERANGE TO USBCHECKER CLASS 7350R6LITE.................................1.0.0.6
/// ADD ICON TO FAIL AND PASS....................................................1.0.0.7
/// ADD COVERANGE TO PRINTER REC 7350R6LITE......................................1.0.0.8
/// ADD COVERANGE TO PRINTER SERIAL_NUMBER, MAIN_FIRMWARE........................1.0.0.9
/// ADD IMAGECHEK................................................................1.0.1.2
/// ADDD CADD_ANALISIS_LOG.......................................................1.0.1.3
/// ADD 10 SECONNDS BEFORE TO START CADD ANALISIS TO FIX 4GB ISSUE...............1.0.1.4
/// ADD XML REPORT TO USBCHECKER.................................................1.0.2.0/// ADD REFRESH TABLE TO CREATE XMLREPOT...........................1.0.2.1
/// ADD COVERANGE TO IOBOARD AND TOUCHVP TO CLASS 7358...........................1.0.2.2
/// ADD PATH TO SAVE BACKUP FILELOGS USBCHECKER..................................1.0.2.3
/// ADD XML REPORT IN CADD_ANALISIS CHECKHEALTH..................................1.0.2.4
/// ADD COVERGANE USB CHECKER TO 7350 R5 CLASS...................................1.0.2.5
/// ADD COVERANGE CADD CHECKER TO CLASS 7350 R5..................................1.0.2.6
/// ADD COVERANGE VALIDATIOR EGALE LOCK..........................................1.0.2.7
/// ADD FIX NON REPORT FAILURES..................................................1.0.2.8
/// ADD EVALUATION START SERVICE NCRLOADER.......................................1.0.2.9
/// VALIDATION CHANGE NAME TO FILE LOG TO CADD_ANALISIS..........................1.0.3.0
/// ADD REPORTING TO SERVER CADDCHECKER..........................................1.0.3.1
/// FIX STATUS FAIL CHECKIOBOARD.................................................1.0.3.2
/// ADD MENU DEBUG MODE..........................................................1.0.3.3
/// ADD LOGIN CLASS WITH WINDOWS USER AND PASSWORD...............................1.0.3.4 WRONG FUNCTION
/// FIX ISSUE SERIAL_NUMBER UPS..................................................1.0.3.5
/// ADD FUNCTION TO DELETE DE ADDFW.DAT FILE WITH THE DATAGRIDVIEW...............1.0.3.6
/// ADD SPECIFIC TIME TO START CADD_ANALISIS TO 7362.............................1.0.3.7
/// ADD COVERAGE TO PIDVID CAMERA................................................1.0.3.8 
/// ENABLE BUTTON DEBUG IN DEBUG MODE............................................1.0.3.9
/// ADD PORCENT INDICATOR........................................................1.0.4.0
/// ADD VERIFYIMAGE TO CLASS 7362................................................1.0.4.1
/// ADD RUN EXTERNAL EXE TO BE MONITORING THE NCRLOADER SERVICES.................1.0.4.2
/// ADD DISPLAYTEST TO GET CORRECT PART NUMBER BY FEATURES.......................1.0.4.3
/// ADD FIX TO STREAM READER CLOSE TRACER.EJL CLASS PNDisplay....................1.0.4.4
/// ADD NEW PIDVID VIP 0C45 PID 6708 TO CAMERA TEST..............................1.0.4.5
/// ADD NEW TEST TO VALIDATE TRACER WIP VS WIP SCANNED...........................1.0.4.6
/// DATAGRIDVIEW FAILURES DELETE .DAT FILE DOUBLECLICK FIX.......................1.0.4.7
/// FIX COVERANGE WHEN THE IOBOARD NOT FUNCTION CORRECTLY........................1.0.4.8
/// ADD RESOURCE AND STEP NAME DISPLAY PN TEST-SDISP01TE01.......................1.0.4.9
/// ADD FUNCTION TO ORGANIZE THE OUTPUT XML FILES................................1.0.5.1
/// ADD 50 SECONTS TO WAIT TO START CADDCHECKER TEST TO CLASS 7362...............1.0.5.2
/// 02/AGOSTO/2019  ADD EBOX TEST TO CLASS 7350R5 "CORE TEST"....................1.0.5.3
/// 06/AGOSTO/2019 ADD NEW IMAGE AND ANIMATION WHILE CADD ANALISYS IS RUNNING ...1.0.5.4
/// 06/AGOSTO/2019 ADD NEW WINDOWS SYTLE AND ANIMATION WHEN THE CADD FAIL.... ...1.0.5.5
/// 09/AGOSTO/2019 ADD COVERANGE USBCHECKER TO SCN CASH ACCEPTOR............. ...1.0.5.6
/// 15/AGOSTO/2019 SE AGREGA FUNCION PARA QUE CORRA EN SEGUNDO PLANO CADDCHECKER.1.0.5.7
/// 19/AGOSTO/2019 7350 USB BCR !_BuildType.Contains("NO_CURR_MODULES")).........1.0.5.8
/// 19/AGOSTO/2019 REVERT UPDATE TAKS.FACTORYSTART FROM CADDCHECKER..............1.0.5.9
/// 19/AGOSTO/2019 REVERT UPDATE TAKS.FACTORYSTART FROM CADDCHECKER..............1.0.5.9
/// 28/AGOSTO/2019 UPDATE COVERANGE TO 7350 POCONO TOUCH VID PID.................1.0.6.0
/// 28/AGOSTO/2019 ADD DISPLAY RAM AND CPU TYPE VERIFICATION.....................1.0.6.1
/// 30/AGOSTO/2019 DELETE VERIFICACION BOOT FIRMWARE IOBOARD MISCF...............1.0.6.2
/// 04/SEPTIEMBRE/2019 ADD COVERANGE TO CHECK PRINTER VERSION MAIN FIRMWARE......1.0.6.3
/// 19/SEPTIEMBRE/2019 ADDED FUNCTION IF ONE SOME TEST FAIL THE PRE-TEST IS STOPPED......1.0.6.4
/// 
/// 
/// 
/// 23/SEPTIEMBRE/2019 ADDED FUNCTION TO SAVE RECORD THE DIAGNOSTIC AND REPAIR IN DATABASE.........1.0.7.0
/// 23/SEPTIEMBRE/2019 FIRST REALEASE NEW CADD ANALISIS VERSION 1.0.7.1............................1.0.7.1
/// 23/SEPTIEMBRE/2019 FIX USBCHECKER CASH-ACCEPTOR 7350MC4712.....................................1.0.7.2
/// 24/SEPTIEMBRE/2019 DISABLE DEBUG MODE, AND EXIT APP............................................1.0.7.3
/// 24/SEPTIEMBRE/2019 DISABLE BUTTN DEBUG MODE, AND BUTTON EXIT APP...............................1.0.7.4
/// 24/SEPTIEMBRE/2019 ADD USER FCO MARQUEZ DIAGNOSTIC AND REPAIR..................................1.0.7.5
/// 26/SEPTIEMBRE/2019 FIX ERROR WAS MISSING THE USER NAME TO CADDCHECER XML TAB...................1.0.7.6
/// 26/SEPTIEMBRE/2019 ENABLE CHECK SCALE IN CADDCHECKER TO 7350R5.................................1.0.7.7
/// 27/SEPTIEMBRE/2019 ADD VERIFY TRACER TEST TO CLASS 7350R5......................................1.0.7.8
/// 30/SEPTIEMBRE/2019 ADDED VERIFY TPM CHIP 2.0...................................................1.0.7.9
/// 30/SEPTIEMBRE/2019 ADDED BUTTON TO OPEN PML FROM CADD ANALISIS.................................1.0.8.0
/// 01/OCTUBRE/2019 ADDED RECORD FAILURE TO VERIFY TRACER AND DISPLAY PN...........................1.0.8.1
/// 01/OCTUBRE/2019 CHECK BUILDTYPE BEFORE TO TEST.................................................1.0.8.2
/// 01/OCTUBRE/2019 ADDED TRILIGHT TEST TO CLASS 7358 N 7360.......................................1.0.8.3
/// 01/OCTUBRE/2019 FIX DIAGNOSTIC xml:space="preserve"............................................1.0.8.4
/// 02/OCTUBRE/2019 ADDED TEST TO CHECK DIP READER MSR SANKYO......................................1.0.8.5
/// 03/OCTUBRE/2019 ADDED SERIAL NUMBER COLUMN CADDCHECKER RECORD..................................1.0.8.6
/// 03/OCTUBRE/2019 ADDED USER NAME COLUMN CADDCHECKER RECORD......................................1.0.8.7
/// 18/OCTUBRE/2019 ADDED FUNCTION TO RUN GETDIAGFILES AND COPY ZIP TO PANGAEA AUTOMATIC...........1.0.8.8
/// 18/OCTUBRE/2019 FIXED ADDED FUNCTION TO RUN GETDIAGFILES AND COPY ZIP TO PANGAEA AUTOMATIC.....1.0.8.9
/// 30/OCTUBRE/2019 ADD AUTOMATION USB CHECKER.....................................................1.0.9.0
/// 01/NOVEMBER/2019 FIX TO ELIMINATE CRASHING APPLICATION WHEN AUTOMATION IS ENABLE...............1.0.9.1
/// 01/NOVEMBER/2019 ADD AUTOMATION CADD CHECKER...................................................1.0.9.2
/// 05/NOVEMBER/2019 ADD COVERANGE TO CHECK TWO TYPES OF VID PIDs FRO BIOMETRIC MODULES............1.0.9.3
/// 05/NOVEMBER/2019 VALIDATION MAIN FUNCTION MONITOR PROCESS WIHT TIMER 150MS.....................1.0.9.4
/// 05/NOVEMBER/2019 SCO6_EMPLOYE AUTOMATION.......................................................1.0.9.5
/// 06/NOVEMBER/2019 NOTIFICATION WHEN THE UNIT PRE TEST IS COMPLETED..............................1.0.9.6
/// 07/NOVEMBER/2019 NOTIFICATION WHEN THE UNIT PRE TEST IS COMPLETED AND UNIT IS FAILED...........1.0.9.7
/// 25/NOVEMBER/2019 ADD DIAGS IN DIAG FAILURE LIST................................................1.0.9.8
/// 02/DICEMBER/2019 ADD COVERANGE TO CHECK USB MSR SANYO DIP READER...............................1.0.9.9
/// 13/DICEMBER/2019 ADD FUNCTION TO ACTIVATE SOUND AND VOLUP WHIE TIMERBEEP IS ACTIVE.............1.1.0.0
/// 23/DICEMBER/2019 ADD WAIT 200ms BEFORE TO CLICK START TEST FOR AUTOMATION SCRIPTS..............1.1.0.1
/// 09/ENERO/2020 ADD CLASS REPORTINGSEM TO CREATE XML LOG FOR USBCHECKER AND CADDCHECKER..........1.1.0.2
/// 09/ENERO/2020 REMOVE FUNCTION TO CHECK IMAGE HAS BEEN INSTALLED BEFORE TO START PANGAEA........1.1.0.4
/// 09/ENERO/2020 COMMENTS FUNCTION TO CREATE XML REPORT TO SEMAPHORE..............................1.1.0.5
/// 09/ENERO/2020 ADD CONDITION TO CHECK UPS 220 UPS_220V_NOTAB....................................1.1.0.6
/// 21/ENERO/2020 ADD CONDITIONS FOR CADDCHECKER 7350R6LITE........................................1.1.0.7
/// 21/ENERO/2020 ADD CONDITIONS FOR MEI BNR MODULE FOR 7350R6LITE.................................1.1.0.8
/// 02/FEBRERO/2020 IMPLEMENTATION SEMPAHORE REPORTING USB-CHECKER, CADD-CHECKER...................1.1.0.9
/// 02/FEBRERO/2020 ADD COLUMN OPERATOR REPORINTG SEMAPHORE........................................1.1.1.0
/// 06/FEBRERO/2020 ADD COLUMN PROGRESS REPORINTG SEMAPHORE........................................1.1.1.1
/// 06/FEBRERO/2020 ADD COVERANGE TO CHECKHEALTH UPS...............................................1.1.1.2
/// 11/MARZO/2020 FIX DELETE EXTRA SPACE IN VARIABLE FROM PNDISPLAY................................1.1.1.3
/// 11/MARZO/2020 ADD COVERANGE TO CADDCHECKER TO VERIFY MSR DIP READER............................1.1.1.3
/// 11/MARZO/2020 FIX BUD TO CHECK CAMERA IN DISPLAY WITHOUT CAMERA................................1.1.1.4
/// 11/MARZO/2020 FIX BUG NO_UPS BUILDTYPE.........................................................1.1.1.5
/// 11/MARZO/2020 FIX BUG FOR UNITS WITH FEAT FULL_RECYCLING_2D....................................1.1.1.6
/// 11/MARZO/2020 FIX BUG FOR UPS CHECKHEALTH CLOSE POSPowerMonitor MFC APPLICATION................1.1.1.7
/// 
/// 
/// 
/// 
/// 
/// </summary>




namespace FixR6LitePrinter
{
    public partial class Form1 : Form
    {
        string version = "v1.1.1.7"; //Version de aplicacion
        bool _WindowsState;
        string _PreTest;


        public Form1(string input) //Funcion que determina si la aplicacion inicia visible
        {
            _WindowsState = bool.Parse(input.ToString());
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            InicializarDataGridView();
            lblVersion.Text = version;

            InitReadDiagnosticsPendings();
        }

        bool _WrongImage;
        bool _StepHipot;
        string _LastStep;
        string _InQueue;
        int _Flag = 0;
        int _FlagUSBChecker = 0;
        int _FlagBuildType = 0;
        string _Class;
        IntPtr _CADD;
        string _NameWindow = "CADD-UI";
        StreamReader _sReader;

        int PRERESULT = 0;
        int RESULTADO = 0;
        int CADD_LOOP = 0;


        string USB = "USB_CHECKER";
        string CADD = "CADD_CHECKER";
        string EBOX = "EBOXTest";
        string PASS = "PASS";
        string FAIL = "FAIL";
        string ADDFW_DELETE = "";
        string DESCONECTADO = "DESCONECTADO";
        string CONECTADO = "CONECTADO";
        string TRACER;
        string SERIALNUMBER;
        string CLASS;
        string MC;


        //Variables para modificar sonido de pc
        private const int APPCOMMAND_VOLUME_MUTE = 0x80000;
        private const int APPCOMMAND_VOLUME_UP = 0xA0000;
        private const int APPCOMMAND_VOLUME_DOWN = 0x90000;
        private const int WM_APPCOMMAND = 0x319;


        //Automation sscos settings
        string _dirAutomationSettings = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config files\SSCOs Automation.ini";
        string _automationFlag;


        GetSerialClassMC.GetSerialClassMC getMC = new GetSerialClassMC.GetSerialClassMC();
        CADD_ANALISIS.History _ADDEvent = new CADD_ANALISIS.History();
        CADD_ANALISIS.PNDisplay PNDisplay = new CADD_ANALISIS.PNDisplay();
        CADD_ANALISIS.ValidateTracerWip ValidateTracerByWip = new CADD_ANALISIS.ValidateTracerWip();
        CADD_ANALISIS.IniFiles iniFiles = new CADD_ANALISIS.IniFiles();
        CADD_ANALISIS.History _reporting = new CADD_ANALISIS.History();
        CADD_ANALISIS.ReportingSem reportingSem;


        [DllImport("user32.dll")]
        public static extern IntPtr SendMessageW(IntPtr hWnd, int Msg,IntPtr wParam, IntPtr lParam);

        private void VolUp()
        {
            SendMessageW(this.Handle, WM_APPCOMMAND, this.Handle,
                (IntPtr)APPCOMMAND_VOLUME_UP);
        }



        private void timMonitorProcess_Tick(object sender, EventArgs e)
        {
            try
            {
                _CADD = API.FindWindow(null, _NameWindow);

                if (_FlagBuildType == 0)
                {
                    if (!File.Exists(@"c:\build.typ"))
                    {
                        _FlagUSBChecker = 1;
                    }

                    if (File.Exists(@"c:\build.typ"))
                    {
                        System.Threading.Thread.Sleep(100);
                        _FlagBuildType = 1;
                        _Class = CheckImage();
                        //_WrongImage = VerifyImage();
                        _WrongImage = false;

                        if (_WrongImage)
                        {
                            WriteDGV("FAIL", DateTime.Now, "VERIFICACION DE IMAGEN", "!!!IMAGEN EQUIVOCADA!!!");
                            this.Visible = true;
                            _Flag = 0;
                            _FlagUSBChecker = 1;
                        }

                        if (_FlagUSBChecker == 1)
                        {
                            _FlagUSBChecker = 0; //Fixed crashing automation script on validation 01 november 2019
                            btnEboxTest.Enabled = false;
                            btnAnalizar.Enabled = false;
                            btnContinuar.Enabled = false;
                            btnUSBChecker.Enabled = true;
                            if (_Class == "7350R5") btnEboxTest.Enabled = true;
                            this.Visible = true;
                            this.Refresh();
                            timMonitorProcess.Stop();

                            //Settings Automation script
                            _automationFlag = iniFiles.reader("CADD_ANALISIS", "UsbChecker", _dirAutomationSettings);
                            if (_automationFlag == "true")
                            {
                                btnUSBChecker.Enabled = false;
                                System.Threading.Thread.Sleep(2500);
                                btnUSBChecker_Click(sender, e);
                            }
                        }
                    }
                }


                if (_CADD != IntPtr.Zero || _Flag == 1)
                {
                    _Flag = 1;

                    if (_CADD == IntPtr.Zero)
                    {
                        _Flag = 2;
                    }
                }

                if (_Flag == 2)
                {
                    btnEboxTest.Enabled = false;
                    btnAnalizar.Enabled = true;
                    btnContinuar.Enabled = false;
                    btnUSBChecker.Enabled = false;
                    this.Visible = true;
                    this.Refresh();
                    timMonitorProcess.Stop();
                    _Flag = 0;

                    //Settings Automation script
                    _automationFlag = iniFiles.reader("CADD_ANALISIS", "CaddChecker", _dirAutomationSettings);
                    if (_automationFlag == "true")
                    {
                        btnAnalizar.Enabled = false;
                        System.Threading.Thread.Sleep(2500);
                        btnAnalizar_Click(sender, e);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }



        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e) //Subproceso que monitorea el arranque de Pangaea y ADDSupport
        {
            while (true)
            {
                try
                {                   
                    _CADD = API.FindWindow(null, _NameWindow);

                    if (_FlagBuildType == 0)
                    {
                        if (!File.Exists(@"c:\build.typ"))
                        {
                            _FlagUSBChecker = 1;
                        }

                        if (File.Exists(@"c:\build.typ"))
                        {
                            System.Threading.Thread.Sleep(100);
                            _FlagBuildType = 1;
                            _Class = CheckImage();
                            _WrongImage = VerifyImage();

                            if (_WrongImage)
                            {
                                WriteDGV("FAIL", DateTime.Now, "VERIFICACION DE IMAGEN", "!!!IMAGEN EQUIVOCADA!!!");
                                this.Visible = true;
                                _Flag = 0;
                                _FlagUSBChecker = 1;
                            }

                            if (_FlagUSBChecker == 1)
                            {
                                _FlagUSBChecker = 0; //Fixed crashing automation script on validation 01 november 2019
                                btnEboxTest.Enabled = false;
                                btnAnalizar.Enabled = false;
                                btnContinuar.Enabled = false;
                                btnUSBChecker.Enabled = true;
                                if (_Class == "7350R5") btnEboxTest.Enabled = true;
                                this.Visible = true;

                               //Settings Automation script
                                _automationFlag = iniFiles.reader("CADD_ANALISIS", "UsbChecker", _dirAutomationSettings);
                                if (_automationFlag == "true")
                                {
                                    btnUSBChecker.Enabled = false;
                                    System.Threading.Thread.Sleep(2500);
                                    btnUSBChecker_Click(sender, e);
                                }
                            }
                        }
                    }


                    if (_CADD != IntPtr.Zero || _Flag == 1)
                    {
                        _Flag = 1;

                        if (_CADD == IntPtr.Zero)
                        {
                            _Flag = 2;
                        }
                    }

                    if (_Flag == 2)
                    {
                        btnEboxTest.Enabled = false;
                        btnAnalizar.Enabled = true;
                        btnContinuar.Enabled = false;
                        btnUSBChecker.Enabled = false;
                        this.Visible = true;
                        _Flag = 0;

                        //Settings Automation script
                        _automationFlag = iniFiles.reader("CADD_ANALISIS", "CaddChecker", _dirAutomationSettings);
                        if (_automationFlag == "true")
                        {
                            btnAnalizar.Enabled = false;
                            System.Threading.Thread.Sleep(2500);
                            btnAnalizar_Click(sender, e);
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

        void InicializarDataGridView()
        {
            //dgvFailures.Columns.Add("status", "Status");
            dgvFailures.Columns.Add("date", "Fecha");
            dgvFailures.Columns.Add("module", "Modulo");
            dgvFailures.Columns.Add("comments", "Comentarios");

            //dgvFailures.Columns["status"].Width = 60;
            dgvFailures.Columns["date"].Width = 125;
            dgvFailures.Columns["module"].Width = 150;
            dgvFailures.Columns["comments"].Width = 700;
            dgvFailures.RowHeadersVisible = false;



            dgvLogs.Columns.Add("date", "Date");
            dgvLogs.Columns.Add("module", "Modulo");
            dgvLogs.Columns.Add("comments", "Comentarios");

            dgvLogs.Columns["date"].Width = 125;
            dgvLogs.Columns["module"].Width = 100;
            dgvLogs.Columns["comments"].Width = 400;
            dgvLogs.RowHeadersVisible = false;

            dgvDiagnosticPendings.Columns.Add("date", "Date");
            dgvDiagnosticPendings.Columns.Add("tracer", "Tracer");
            dgvDiagnosticPendings.Columns.Add("module", "Module");        
            dgvDiagnosticPendings.Columns.Add("failure", "Failure");
            dgvFailures.RowHeadersVisible = false;
        }

        void EvalularResultado(int i)
        {
            RESULTADO = i + RESULTADO;
        }

        #region IMAGE_CHECKER
        string CheckImage()
        {
            string _Result = "";
            string _Text = "";

            try
            {
                _Text = File.ReadAllText(@"c:\build.typ");

                if (_Text.Contains("7360"))
                {
                    _Result = "7360"; ///INFO_IMAGE
                }
                if (_Text.Contains("7362"))
                {
                    _Result = "7362"; ///INFO_IMAGE
                }
                if (_Text.Contains("7350") && _Text.Contains("POCONO_BASE"))
                {
                    _Result = "7350R5"; ///INFO_IMAGE
                }
                if (_Text.Contains("7350") && !_Text.Contains("POCONO_BASE"))
                {
                    _Result = "7350R6Lite"; ///INFO_IMAGE
                }
                if (_Text.Contains("7358"))
                {
                    _Result = "7358"; ///INFO_IMAGE
                }
            }

            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                    {
                         "", DateTime.Now, "Application log", ex.Message
                    });

                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }


            return _Result;
        }

        bool VerifyImage()
        {
            bool _Result = false;

            try
            {
                //C:\JABIL\INFO_IMAGE.TXT
                string _Contenido = File.ReadAllText(@"C:\JABIL\INFO_IMAGE.txt");
                if (_Contenido != _Class)
                {
                    _Result = true;
                }


            }
            catch (Exception ex)
            {

            }

            return _Result;

        }
        #endregion

        #region CADDLOGS_CHECKER 

        int ValidateTracer(string TRACER, string SERIALNUMBER, string CLASE, string MC) //Validacion de tracer by wip
        {



            int _result = 0;
            string _ModuleName = "TRACER BY WIP SCANNED";
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string WipScanned = "";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                ValidateTracerByWip.ValidateWip(TRACER);
                WipScanned = ValidateTracerByWip.WIPSCANNEDUNIT;
                _Comments = "WIP: " + SERIALNUMBER + " " + "WIPSCANNED: " + WipScanned;

                if (SERIALNUMBER != WipScanned)
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _Comments = "WIP: " + SERIALNUMBER + " " + "WIPSCANNED: " + WipScanned;
                }
                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic, _SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments,_User, _Diagnostic, _SerialNumber);
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "ERROR VALIDATE TRACER BY WIP");
            }

            return _result;
        }

        int CheckDisplayPartNumber(string TRACER, string CLASE, string MC) //Validacion de Display part number escaneado contra Display part number correcto
        {
            int _result = 0;
            string _RecursoIfactory = "SDISP01TE01"; //Recurso para dar el pass en iFactory
            string _StepNameIfactory = "DISPLAY PN TEST"; //Nombre del step en iFactory
            string _ModuleName = _StepNameIfactory + "-" + _RecursoIfactory;
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string DisplayPartNumber = "";
            string DisplayPartAssy = "";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                PNDisplay.PNDisplayTest(TRACER, CLASE, MC);

                DisplayPartNumber = PNDisplay.DisplayPartNumber;
                DisplayPartAssy = PNDisplay.DisplayPartAssy;

                _Comments = "Esperado: " + DisplayPartNumber + " " + "Encontrado: " + DisplayPartAssy;

                if (DisplayPartNumber != DisplayPartAssy)
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _Comments = "Esperado: " + DisplayPartNumber + " " + "Encontrado: " + DisplayPartAssy;
                }
                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic, _SerialNumber);
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO DISPLAY");
            }
            return _result;
        }

        int CheckUPS() //Validacion de UPS
        {
            int _result = 0;
            string _ModuleName = "UPS";
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";
            string[] _CADDPOSPower_UPS = { };
            bool OPOSPOSPower = false;
            bool NCRPOSPowerSO = false;
            bool ADDConfig_POSPower_UPS = false;
            bool CompletedReg = false;

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_POSPower_UPS_USB.dat");
                _CADDPOSPower_UPS = File.ReadAllLines(@"C:\scot\logs\CADD_POSPower_UPS.log");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("VOLTAGE=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }
           
                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");

                _Comments = string.Join("\n", _list.ToArray());

                Process[] _ProcessByID = Process.GetProcessesByName("POSPowerMonitor");

                if (_ProcessByID.Length > 0)
                {
                    WriteLOGS(DateTime.Now, _ModuleName, "CERRANDO POSPOWER MONITOR.EXE");
                    _ProcessByID[0].Kill();
                }
                else { WriteLOGS(DateTime.Now, _ModuleName, "NO SE ENCONTRO POSPOWER MONITOR.EXE"); }
                

                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0) //Verificacion de UPS CheckHealth
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\UPS\NCR_UPS.exe";
                    _process.StartInfo.Arguments = "UPS checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();

                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }

                if (_flag) //Verificacion FAIL
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false) //Verificacion PASS
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO UPS");
            }
            _sReader.Close();
            return _result;
        }

        int CheckGSR50() //Validacion de Fujitsu GSR50, validacion de firmware, conexiones internas y malos ensambles
        {
            int _result = 0;
            string _ModuleName = "GSR50";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            string _buildtype = File.ReadAllText(@"C:\build.typ");

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashChanger_Fujitsu_GSR50_USB.dat");
                _Contenido = File.ReadAllText(@"C:\scot\logs\ADDFW_CashChanger_Fujitsu_GSR50_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream) //Verificacion de LOGS generados por ADDSupport
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("DRIVER_TYPE=UNKNOWN") || _rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }


                if (_buildtype.Contains("FULL_RECYCLING_2D"))
                {
                    //Verificacion de Recycler frame 1
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_1"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_1 no encontrado ");
                    }
                }


                if (_buildtype.Contains("FULL_RECYCLING_4D"))
                {
                    //Verificacion de Recycler frame 1
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_1"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_1 no encontrado ");
                    }

                    //Verificacion de Recycler frame 2
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_2"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_2 no encontrado");
                    }
                }

                if (_buildtype.Contains("FULL_RECYCLING_6D"))
                {
                    //Verificacion de Recycler frame 1
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_1"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_1 no encontrado ");
                    }

                    //Verificacion de Recycler frame 2
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_2"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_2 no encontrado");
                    }

                    //Verificacion de Recycler frame 3
                    if (!_Contenido.Contains("SerialNumber_Recycler_Frame_3"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: SerialNumber_Recycler_Frame_3 no encontrado");
                    }
                }


                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "GETGSR50INFO MAIN_FIRMWARE...");

                if (_result == 0) //Validacion de Main firmware
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 MAIN_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();

                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                WriteLOGS(DateTime.Now, _ModuleName, "GETGSR50INFO BOOT_FIRMWARE...");

                if (_result == 0) //Validacion de Boot firmware
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 BOOT_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_buildtype.Contains("FULL_RECYCLING_2D"))
                {
                    if (_result == 0) //Validacion de SN Recycler1
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_1";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }
                }
               
                _Comments = string.Join("\n", _list.ToArray());

                if (_buildtype.Contains("FULL_RECYCLING_4D"))
                {
                    if (_result == 0) //Validacion de SN Recycler1
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_1";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }

                    if (_result == 0) //Validacion de SN Recycler 2
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_2";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }
                }

                _Comments = string.Join("\n", _list.ToArray());

                if (_buildtype.Contains("FULL_RECYCLING_6D"))
                {
                    if (_result == 0) //Validacion de SN Recycler1
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_1";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }

                    if (_result == 0) //Validacion de SN Recycler 2
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_2";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }

                    if (_result == 0) //Validacion de SN Recycler 3
                    {
                        string _ProgStatus = "";
                        Process _process = new Process();
                        _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                        _process.StartInfo.Arguments = "CashChanger_Fujitsu_GSR50 SerialNumber_Recycler_3";
                        _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        _process.Start();
                        _process.WaitForExit();
                        _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                        if (_ProgStatus != "0")
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _result = 1;
                            _list.Add(_ProgStatus);
                        }
                    }
                }

                _Comments = string.Join("\n", _list.ToArray());

                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0) //Verificacion Checkhealth fujitsu GSR50
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CashAD\NCR_CashAD.exe";
                    _process.StartInfo.Arguments = "Fujitsu_GSR50  checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();

                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }

                _Comments = string.Join("\n", _list.ToArray());

                if (_flag) //Verificacion FAIL
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }

                if (_flag == false) //Verificacion PASS
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO GSR50");
            }
            _sReader.Close();
            return _result;
        }

        int CheckCRANE() //Validacion de CR5000, validacion de firmware, conexiones internas y malos ensables
        {
            int _result = 0;
            string _ModuleName = "CR5000";
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashChanger_Crane_Xchange_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream) //Verificacion de LOGS generados por ADDSupport
                {
                    string _rLine = _sReader.ReadLine();
                    if (_rLine.Contains("DRIVER_TYPE=UNKNOWN") || _rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0) //Verificacion CheckHealth CR5000
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CoinAD\NCR_CoinAD.exe";
                    _process.StartInfo.Arguments = "Crane_Xchange checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag) //Validacion FAIL
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false) //Validacion PASS
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO CR5000");
            }
            _sReader.Close();
            return _result;
        }

        int CheckMEIBNR() //Validacion de MEI-BNR recycler, validacion de firmware, conexiones internas y malos ensambles
        {
            int _result = 0;
            string _ModuleName = "MEI BNR";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {

                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashChanger_MEI_BNR_USB.dat");
                _Contenido = File.ReadAllText(@"C:\scot\logs\ADDFW_CashChanger_MEI_BNR_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream) //Verificacion de LOGS generados por ADDSupport
                {
                    string _rLine = _sReader.ReadLine();
                    if (_rLine.Contains("DRIVER_TYPE=UNKNOWN") || _rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }
                if (!_Contenido.Contains(""))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento:  no encontrado ");
                }
                if (!_Contenido.Contains(""))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento:  no encontrado ");
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0) //Verificacion Checkhealth 
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CashAD2\NCR_CashAD2.exe";
                    _process.StartInfo.Arguments = "MEI_BNR checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag) //Validacion FAIL
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);                
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false) //Validacion PASS
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO GSR50");
            }
            _sReader.Close();
            return _result;
        }

        int CheckPrinter() //Validacion de Printer SSCO6
        {
            int _result = 0;
            string _ModuleName = "PRINTER";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_POSPrinter_NCR_HIDReceipt_USB.dat");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");
                while (!_sReader.EndOfStream) //Verificacion de LOGS generados por ADDSupport
                {
                    string _rLine = _sReader.ReadLine();
                    if (_rLine.Contains("SOMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }
                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO SERVICIO NCRLOADER");

                //Verificacion de Servicio NCRLoader activo
                string _ServiceName = "NCRLoader";
                ServiceController _Service = new ServiceController(_ServiceName);
                int timeoutMilisegundos = 40000;
                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilisegundos);
                if (_Service.Status == ServiceControllerStatus.Stopped)
                {
                    WriteLOGS(DateTime.Now, _ModuleName, "INICIANDO SERVICIO...");
                    _Service.Start();
                    _Service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                    if (_Service.Status == ServiceControllerStatus.Stopped)
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add("FAILED TO ACTIVATE NCR_LOADER SERVICE...");
                    }
                    WriteLOGS(DateTime.Now, _ModuleName, "SERVICIO INICIADO...");
                }
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO SERIAL_NUMBER...");
                if (_result == 0) //Verificacion de Serial number 
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_HIDReceipt SERIAL_NUMBER";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO MAIN_FIRMWARE...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_HIDReceipt MAIN_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    string _logResult = @"c:\Pangaea\SCO6\logs\temp.ejl";
                     _logResult = File.ReadAllText(_logResult);

                    if (!_logResult.Contains("V61.62")) _ProgStatus = "Main firmware expected: V61.62";



                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO BOOT_FIRMWARE...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_HIDReceipt BOOT_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\Printer\NCR_Printer.exe";
                    _process.StartInfo.Arguments = "NCR_HIDReceipt checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic, _SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO PRINTER");
                _result = 1;
            }

            _sReader.Close();
            return _result;
        }

        int CheckPrinterREC()
        {
            int _result = 0;
            string _ModuleName = "PRINTER_REC";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_POSPrinter_NCR_Receipt_USB.dat");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("SOMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }

                }
                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO SERVICIO NCRLOADER");

                string _ServiceName = "NCRLoader";
                ServiceController _Service = new ServiceController(_ServiceName);
                int timeoutMilisegundos = 40000;
                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilisegundos);

                if (_Service.Status == ServiceControllerStatus.Stopped)
                {
                    WriteLOGS(DateTime.Now, _ModuleName, "INICIANDO SERVICIO...");
                    _Service.Start();
                    _Service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                    if (_Service.Status == ServiceControllerStatus.Stopped)
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add("FAILED TO ACTIVATE NCR_LOADER SERVICE...");
                    }
                    WriteLOGS(DateTime.Now, _ModuleName, "SERVICIO INICIADO...");
                }
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO SERIAL_NUMBER...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_Receipt SERIAL_NUMBER";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO MAIN_FIRMWARE...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_Receipt MAIN_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "GETPRINTERINFO BOOT_FIRMWARE...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CADDGetInfo\NCR_CADDGetInfo.exe";
                    _process.StartInfo.Arguments = "POSPrinter_NCR_Receipt BOOT_FIRMWARE";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\Printer\NCR_Printer.exe";
                    _process.StartInfo.Arguments = "NCR_Receipt checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO PRINTER");
                _result = 1;
            }
            _sReader.Close();
            return _result;
        }   

        int CheckBCR()
        {
            int _result = 0;
            string _ModuleName = "BCR MONEYCONTROL";
            string _Comments = null;
            bool _flag = false;
            string _Contenido = "";
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashChanger_MoneyControls_BCR_USB.dat");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");
                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("CURRENCY1=........") || _rLine.Contains("CURRENCY2=........") || _rLine.Contains("CURRENCY3=........") || _rLine.Contains("CURRENCY4=........") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN") || _rLine.Contains("ACCEPT_SERIAL_NUMBER=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }
                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CoinA\NCR_CoinA.exe";
                    _process.StartInfo.Arguments = "MoneyControls_BCR checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();

                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                    WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO EAGLE LOCK...");
                    System.Threading.Thread.Sleep(30000);
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CoinA\NCR_CoinA.exe";
                    _process.StartInfo.Arguments = "MoneyControls_BCR checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                WriteLOGS(DateTime.Now, _ModuleName, "SENSORINAC...");
                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CoinD\NCR_CoinD.exe";
                    _process.StartInfo.Arguments = "MoneyControls_BCR sensorinac";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments,_User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO BCR MONEYCONTROL");
            }
            _sReader.Close();
            return _result;
        }

        int CheckFujitsuF53()
        {
            int _result = 0;
            string _ModuleName = "FUJITSUF53 DISPENSER";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {

                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashChanger_Fujitsu_F53_USB.dat");
                _Contenido = File.ReadAllText(@"C:\scot\logs\ADDFW_CashChanger_Fujitsu_F53_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("DRIVER_TYPE=UNKNOWN") || _rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") /*|| _rLine.Contains("SERIAL_NUMBER=UNKNOWN")*/ || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");

                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CashD\NCR_CashD.exe";
                    _process.StartInfo.Arguments = "Fujitsu_F53 checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (_flag == false)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO FUJITSU F53");
            }
            _sReader.Close();
            return _result;
        }

        int CheckSCNCashAcceptor()
        {
            int _result = 0;
            string _ModuleName = "SCN CASHACCEPTOR";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_CashAcceptor_MEI_ZT_SC_USB.dat");
                _Contenido = File.ReadAllText(@"C:\scot\logs\ADDFW_CashAcceptor_MEI_ZT_SC_USB.dat");
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("SOMODEL=UNKNOWN") || _rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MODEL=UNKNOWN") || _rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN") || _rLine.Contains(" VIDPID=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\CashA\NCR_CashA.exe";
                    _process.StartInfo.Arguments = "MEI_ZT_SC checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }

                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings(); 
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO FUJITSU F53");
            }
            _sReader.Close();
            return _result;
        }

        int CheckIOBoard()
        {
            int _result = 0;
            string _ModuleName = "IOBOARD";
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_MiscIF_NCR_DigitalInterface_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    //if (_rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN") || _rLine.Contains("BOOT_FIRMWARE=UNKNOWN"))
                    if (_rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }

                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }

                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("FAIL", DateTime.Now, _ModuleName, "NO SE ENCONTRO IO-BOARD");
                _result = 1;
            }
            _sReader.Close();
            return _result;
        }

        int CheckMSR()
        {
            int _result = 0;
            string _ModuleName = "MSR SANKYO ICM330";
            string _Comments = null;
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_MSR_Sankyo_ICM330_USB.dat");

                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();
                    
                    if (_rLine.Contains("SERIAL_NUMBER=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\MSR\NCR_MSR.exe";
                    _process.StartInfo.Arguments = "Sankyo_ICM330 checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments,_User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }

                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("FAIL", DateTime.Now, _ModuleName, "NO SE ENCONTRO IO-BOARD");
                _result = 1;
            }
            _sReader.Close();
            return _result;
        }

        int CheckScale()
        {
            int _result = 0;
            string _ModuleName = "SCALE";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string Ncr_calib = @"C:\JABIL\Scale calibration.exe";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                _sReader = new StreamReader(@"C:\scot\logs\ADDFW_Scale_NCR_Bag_USB.dat");
                _Contenido = File.ReadAllText(@"C:\scot\logs\ADDFW_Scale_NCR_Bag_USB.dat");

                //STEP 1 PROCESO
                WriteLOGS(DateTime.Now, _ModuleName, "VERIFICANDO LOGS...");
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                while (!_sReader.EndOfStream)
                {
                    string _rLine = _sReader.ReadLine();

                    if (_rLine.Contains("INIMODEL=UNKNOWN") || _rLine.Contains("MAIN_FIRMWARE=UNKNOWN") || _rLine.Contains("BOOT_FIRMWARE=UNKNOWN"))
                    {
                        _flag = true;
                        _result = 1;
                        _Status = "FAIL";
                        _list.Add("Evento: " + _rLine + " ");
                    }
                }

                if (!_Contenido.Contains("POD1_SERIAL_NUMBER"))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento: POD 1 no encontrado ");
                }

                if (!_Contenido.Contains("POD2_SERIAL_NUMBER"))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento: POD 2 no encontrado ");
                }

                if (!_Contenido.Contains("POD3_SERIAL_NUMBER"))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento: POD 3 no encontrado ");
                }

                if (!_Contenido.Contains("POD4_SERIAL_NUMBER"))
                {
                    _flag = true;
                    _result = 1;
                    _Status = "FAIL";
                    _list.Add("Evento: POD 4 no encontrado ");
                }

                WriteLOGS(DateTime.Now, _ModuleName, "LOGS VERIFICADOS");
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\Scale\NCR_Scale.exe";
                    _process.StartInfo.Arguments = "NCR_Bag checkhealth";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO SCALE");
            }
            _sReader.Close();
            return _result;
        }

        int CheckTriLight()
        {
            int _result = 0;
            string _ModuleName = "TRI-LIGHT";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";
            string _User = "";
            string _SerialNumber = "";

            try
            {
                List<string> _list = new List<string>();
                WriteLOGS(DateTime.Now, _ModuleName, "CHECKHEALTH...");

                if (_result == 0)
                {
                    string _ProgStatus = "";
                    Process _process = new Process();
                    _process.StartInfo.FileName = @"C:\SCO_POS\SCO6\TestExecutables\mei\NCR_Mei.exe";
                    _process.StartInfo.Arguments = "NCR_DigitalInterface_LaneLight lanetrilight";
                    _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    _process.Start();
                    _process.WaitForExit();
                    _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");

                    if (_ProgStatus != "0")
                    {
                        _flag = true;
                        _Status = "FAIL";
                        _result = 1;
                        _list.Add(_ProgStatus);
                    }
                }
                _Comments = string.Join("\n", _list.ToArray());

                if (_flag)
                {
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    SaveFailure(DateTime.Now.ToString(), TRACER, _ModuleName, _Comments);
                    InitReadDiagnosticsPendings();
                }
                if (!_flag)
                {
                    var tup = DiagnosticPending(_ModuleName);
                    _Diagnostic = tup.Item1;
                    _Comments = tup.Item2;
                    _User = tup.Item3;
                    _SerialNumber = tup.Item4;
                    if (_Diagnostic != "") WriteDGV("DIAG", DateTime.Now, _ModuleName, "Diagnostico " + _User + ": " + _Diagnostic);
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoCADDTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments, _User, _Diagnostic,_SerialNumber);
                    InitReadDiagnosticsPendings();
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
                WriteDGV("CHECK", DateTime.Now, _ModuleName, "NO SE ENCONTRO SCALE");
            }
            _sReader.Close();
            return _result;
        }

        int CheckRAMTest()
        {
            int _result = 0;
            string _ModuleName = "CORE TEST RAM";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";
            string _Diagnostic = "";

            ulong RAM = 0;
            CADD_ANALISIS.EBOXTest EBOXTest = new CADD_ANALISIS.EBOXTest();

            try
            {
                string buildType = File.ReadAllText(@"c:\build.typ");
                EBOXTest.GetMemoryRam();
                RAM = EBOXTest.MEMORY_RAM;

                if(_Class == "7350R5")
                {
                    // TEST RAM 2GB
                    if (buildType.Contains("BASE2") && !buildType.Contains("EXTRA_TWO_GB_MEMORY") && !buildType.Contains("EXTRA_FOUR_GB_MEMORY") && !buildType.Contains("EXTRA_SIX_GB_MEMORY") && !buildType.Contains("EXTRA_14GB"))
                    {
                        ulong LowLimit = 2000000000;
                        ulong UpperLimit = 2500000000;
                        string RAM_EXPECTED = "2GB";
                        _ModuleName = "EBOX TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 4GB
                    if (buildType.Contains("EXTRA_TWO_GB_MEMORY") && buildType.Contains("BASE2"))
                    {
                        ulong LowLimit = 4000000000;
                        ulong UpperLimit = 4500000000;
                        string RAM_EXPECTED = "4GB";
                        _ModuleName = "EBOX TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 6GB
                    if (buildType.Contains("EXTRA_FOUR_GB_MEMORY") && buildType.Contains("BASE2"))
                    {
                        ulong LowLimit = 6000000000;
                        ulong UpperLimit = 6800000000;
                        string RAM_EXPECTED = "6GB";
                        _ModuleName = "EBOX TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 8GB
                    if (buildType.Contains("EXTRA_SIX_GB_MEMORY") && buildType.Contains("BASE2"))
                    {
                        ulong LowLimit = 8000000000;
                        ulong UpperLimit = 8800000000;
                        string RAM_EXPECTED = "8GB";
                        _ModuleName = "EBOX TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 16GB
                    if (buildType.Contains("EXTRA_14GB") && buildType.Contains("BASE2"))
                    {
                        ulong LowLimit = 16000000000;
                        ulong UpperLimit = 172000000000;
                        string RAM_EXPECTED = "16GB";
                        _ModuleName = "EBOX TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }
                }


                if (_Class == "7360" || _Class == "7358")
                {

                    // TEST RAM 4GB
                    if (!buildType.Contains("EXTRA_4GB") && !buildType.Contains("EXTRA_8GB"))
                    {
                        ulong LowLimit = 4000000000;
                        ulong UpperLimit = 4500000000;
                        string RAM_EXPECTED = "4GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 8GB
                    if (buildType.Contains("EXTRA_4GB") || buildType.Contains("8GB_MEMORY"))
                    {
                        ulong LowLimit = 8000000000;
                        ulong UpperLimit = 8800000000;
                        string RAM_EXPECTED = "8GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 16GB
                    if (buildType.Contains("EXTRA_8GB") || buildType.Contains("SIXTEEN_GB_MEMOR"))
                    {
                        ulong LowLimit = 16000000000;
                        ulong UpperLimit = 17200000000;
                        string RAM_EXPECTED = "16GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                }

                if (_Class == "7350R6Lite")
                {
                    // TEST RAM 4GB
                    if (!buildType.Contains("EXTRA_4GB") && !buildType.Contains("EXTRA_8GB") && !buildType.Contains("SIXTEEN_GB_MEMOR"))
                    {
                        ulong LowLimit = 4000000000;
                        ulong UpperLimit = 4500000000;
                        string RAM_EXPECTED = "4GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 8GB
                    if (buildType.Contains("EXTRA_4GB"))
                    {
                        ulong LowLimit = 8000000000;
                        ulong UpperLimit = 8800000000;
                        string RAM_EXPECTED = "8GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }

                    // TEST RAM 16GB
                    if (buildType.Contains("EXTRA_8GB") || buildType.Contains("SIXTEEN_GB_MEMOR"))
                    {
                        ulong LowLimit = 16000000000;
                        ulong UpperLimit = 17200000000;
                        string RAM_EXPECTED = "16GB";
                        _ModuleName = "XR7 TEST RAM: " + RAM_EXPECTED;

                        if (RAM < LowLimit || RAM > UpperLimit)
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                        else if (RAM > LowLimit && RAM < UpperLimit)
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = LowLimit + "  " + RAM.ToString() + "  " + UpperLimit;
                        }
                    }
                }

                if (_flag)
                {
                    _result = 1;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments);
                }

                if (!_flag)
                {
                    _result = 0;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments);
                }
            }

            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
            }

            return _result;
        }

        int CheckCPUTest()
        {
            int _result = 0;
            string _ModuleName = "CORE TEST CPU";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";

            string CPU = "";
            CADD_ANALISIS.EBOXTest EBOXTest = new CADD_ANALISIS.EBOXTest();

            try
            {
                string buildType = File.ReadAllText(@"c:\build.typ");
                EBOXTest.CheckCPUType();
                CPU = EBOXTest.CPU;

                if (_Class == "7350R5")
                {
                    //CELERONG540
                    if (buildType.Contains("CELERON_G540"))
                    {
                        string CPU_EXPECTED = "CELERONG540";
                        _ModuleName = "EBOX TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("g540"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //CELERONG440
                    if (buildType.Contains("CELERON_2GIG"))
                    {
                        string CPU_EXPECTED = "CELERON440";
                        _ModuleName = "EBOX TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("440"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //CORE2E7400
                    if (buildType.Contains("PROC_DUO_2_8_GHZ"))
                    {
                        string CPU_EXPECTED = "CORE2E7400";
                        _ModuleName = "EBOX TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("e7400"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //I32120
                    if (buildType.Contains("INTEL_I3_2120"))
                    {
                        string CPU_EXPECTED = "I32120";
                        _ModuleName = "EBOX TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("i3-2120"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //PENTIUME2160
                    if (buildType.Contains("INTEL_E2610"))
                    {
                        string CPU_EXPECTED = "PENTIUME2160";
                        _ModuleName = "EBOX TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("e2160"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }
                }

                if (_Class == "7358" || _Class == "7360")
                {
                    //CELERON G1820TE
                    if (buildType.Contains("INTEL_CELERON") && buildType.Contains("XR7_DISPLAY"))
                    {
                        string CPU_EXPECTED = "CELERONG540";
                        _ModuleName = "CORE TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("G1820TE"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //INTEL i3-4350t
                    if (buildType.Contains("INTEL_I3"))
                    {
                        string CPU_EXPECTED = "INTEL i3-4350t";
                        _ModuleName = "CORE TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("i3-4350t"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }
                }

                if (_Class == "7350R6Lite")
                {
                    //CELERON G1820TE
                    if (buildType.Contains("INTEL_CELERON"))
                    {
                        string CPU_EXPECTED = "CELERON G1820TE";
                        _ModuleName = "XR7 TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("G1820TE"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }

                    //INTEL I3-4350T
                    if (buildType.Contains("INTEL_I3"))
                    {
                        string CPU_EXPECTED = "INTEL I3-4350T";
                        _ModuleName = "XR7 TEST CPU: " + CPU_EXPECTED;

                        if (CPU.Contains("i3-4350t"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                            _Comments = CPU;
                        }
                        else
                        {
                            _flag = true;
                            _Status = "FAIL";
                            _Comments = CPU;
                        }
                    }
                }
                if (_flag)
                {
                    _result = 1;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments);
                }
                if (!_flag)
                {
                    _result = 0;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments);
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _ModuleName, ex.Message);
            }
            return _result;
        }

        int TPM20Test()
        {
            int _result = 0;
            string _ModuleName = "TPM CHIP 2.0";
            string _Comments = null;
            string _Contenido = "";
            bool _flag = false;
            string _Status = "GOOD";

            string TPMDeviceID = "DeviceID=ACPI\\MSFT0101\\1";
            string _sReader = "";
            string filePnPOutPut = @"C:\PnPOutput.txt";

            try
            {
                ExternalExe(@"c:\SCO_POS\pos\TestExecutables\DEVICES\PnPList.bat", "");
                if (!File.Exists(filePnPOutPut))
                {
                    _flag = true;
                    _Status = "FAIL";
                }
                else
                {
                    _sReader = File.ReadAllText(filePnPOutPut);
                    string[] delim = { "\r\n" };
                    string[] deviceListParts = _sReader.Split(delim, StringSplitOptions.None);
                    foreach (string device in deviceListParts)
                    {
                        if (device.Trim().Contains("DeviceID=ACPI\\MSFT0101\\"))
                        {
                            _flag = false;
                            _Status = "GOOD";
                        }
                    }
                }

                if (_flag)
                {
                    _result = 1;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, FAIL, _ModuleName, _Comments);
                }
                if (!_flag)
                {
                    _result = 0;
                    WriteDGV(_Status, DateTime.Now, _ModuleName, _Comments);
                    _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, PASS, _ModuleName, _Comments);
                }
            }
            catch(Exception ex)
            {

            }
            return _result;
        }

        void SaveFailure(string Date, string Tracer, string ModuleName, string Details)
        {
            WriteLOGS(DateTime.Now, "Saving failure " + ModuleName, Details);
            string PathFailures = @"C:\JABIL\FAILURES\";
            if (!Directory.Exists(PathFailures)) Directory.CreateDirectory(PathFailures);
            using (StreamWriter sw = File.CreateText(PathFailures + ModuleName + ".txt"))
            {               
                sw.WriteLine(Date);
                sw.WriteLine(Tracer);
                sw.WriteLine(ModuleName);
                sw.WriteLine(Details);
            }
        }

        void InitReadDiagnosticsPendings()
        {
            try
            {
                WriteLOGS(DateTime.Now, "Verifying diagnostic pendings", "");
                dgvDiagnosticPendings.Rows.Clear();
                string pathFailures = @"C:\JABIL\FAILURES\";
                if (!Directory.Exists(pathFailures)) return;
                DirectoryInfo directoryInfo = new DirectoryInfo(pathFailures);
                FileInfo[] diagnosticsPendings = directoryInfo.GetFiles("*.txt");

                if (diagnosticsPendings.Length <= 0) return;

                foreach(FileInfo file in diagnosticsPendings)
                {
                    string Failure = pathFailures + file;
                    string[] ReadFailure = { "" };
                    ReadFailure = File.ReadAllLines(Failure);
                    WriteDGVDiag("DIAG", ReadFailure[0], ReadFailure[1], ReadFailure[2], ReadFailure[3]);
                }
            }
            catch (Exception ex)
            {
                WriteDGVDiag("DIAG", "", "", ex.Message, "");
            }
        }
        
        Tuple<string, string, string, string> DiagnosticPending(string ModuleName)
        {
            string Failure = @"C:\JABIL\FAILURES\" + ModuleName + ".txt";
            string[] ReadFailure = {""};

            string Date = "";
            string Tracer = "";
            string _ModuleName = "";
            string Details = "";
            string DiagnosticAndRepair = "";
            string User = "";
            string SerialNumber = "";
            DialogResult dr = new DialogResult();

            if (File.Exists(Failure))
            {
                ReadFailure = File.ReadAllLines(Failure);
                System.Threading.Thread.Sleep(1000);
                Date = ReadFailure[0];
                Tracer = ReadFailure[1];
                _ModuleName = ReadFailure[2];
                Details = " Last failure: " + ReadFailure[3];


                CADD_ANALISIS.DiagnosticFailures diagWindow = new CADD_ANALISIS.DiagnosticFailures(Date, Tracer, _ModuleName, Details);

                dr = diagWindow.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    DiagnosticAndRepair = diagWindow.DIAGNOSTICANDREPAIR;
                    User = diagWindow.USER;
                    SerialNumber = diagWindow.SERIAL_NUMBER;
                }

                try
                {
                    File.Delete(Failure);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return Tuple.Create(DiagnosticAndRepair, Date + Details, User, SerialNumber);
        }

        string ExternalExe(string FileName, string Args) 
        {
            string _ProgStatus = "";
            Process _process = new Process();
            _process.StartInfo.FileName = FileName;
            _process.StartInfo.Arguments = Args;
            _process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            _process.Start();
            _process.WaitForExit();
            _ProgStatus = File.ReadAllText(@"C:\progstatus.txt");
            return _ProgStatus;
        }

        #endregion

        bool CheckIsBusy(string FilePathName) //function to validate if the file is busy for another process
        {
            FileStream fileStream = null;
            FileInfo fileInfo = new FileInfo(FilePathName);

            try
            {
                fileStream = fileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (Exception ex)
            {
                return true;
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
            return false;
        }

        #region FUNCTION_DATAGRIDVIEW

        private void dgvFailures_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 2)
                {
                    string Module = dgvFailures.Rows[e.RowIndex].Cells[2].Value.ToString();
                    DeleteADDFW(Module);
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, "APP ERROR", ex.Message);
            }
        }

        void DeleteADDFW(string ADDFWFileName)
        {
            try
            {
                string DatName = "";
                // UPS  
                if (ADDFWFileName == "UPS")
                {
                    DatName = @"C:\scot\logs\ADDFW_POSPower_UPS_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }


                // GSR50
                if (ADDFWFileName == "GSR50")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashChanger_Fujitsu_GSR50_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }


                // CR5000
                if (ADDFWFileName == "CR5000")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashChanger_Crane_Xchange_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }


                // MEI BNR
                if (ADDFWFileName == "MEI BNR")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashChanger_MEI_BNR_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // PRINTER
                if (ADDFWFileName == "PRINTER")
                {
                    DatName = @"C:\scot\logs\ADDFW_POSPrinter_NCR_HIDReceipt_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // PRINTER_REC
                if (ADDFWFileName == "PRINTER_REC")
                {
                    DatName = @"C:\scot\logs\ADDFW_POSPrinter_NCR_Receipt_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }


                // BCR MONEYCONTROL
                if (ADDFWFileName == "BCR MONEYCONTROL")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashChanger_MoneyControls_BCR_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // FUJITSUF53 DISPENSER
                if (ADDFWFileName == "FUJITSUF53 DISPENSER")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashChanger_Fujitsu_F53_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // SCN CASHACCEPTOR
                if (ADDFWFileName == "SCN CASHACCEPTOR")
                {
                    DatName = @"C:\scot\logs\ADDFW_CashAcceptor_MEI_ZT_SC_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // IOBOARD
                if (ADDFWFileName == "IOBOARD")
                {
                    DatName = @"C:\scot\logs\ADDFW_MiscIF_NCR_DigitalInterface_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }

                // SCALE
                if (ADDFWFileName == "SCALE")
                {
                    DatName = @"C:\scot\logs\ADDFW_Scale_NCR_Bag_USB.dat";
                    File.Delete(DatName);
                    WriteLOGS(DateTime.Now, ADDFWFileName, DatName);
                }
                MessageBox.Show("File deleted: " + ADDFWFileName + " " + DatName);
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, ADDFWFileName, ex.Message);
            }
        }

        void WriteDGV(string Status, DateTime date, string ModuleName, string Comments)
        {
            //int icIndex = dgvFailures.Columns.Add(imgCol);
            //dgvFailures.Columns[icIndex].Name = "image";
            try
            {
                if (Status == "FAIL")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVFAIL, date, ModuleName, Comments
                     });
                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.Red;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }
                if (Status == "GOOD")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVGOOD, date, ModuleName, Comments
                     });
                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGreen;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (Status == "CHECK")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVCHECK, date, ModuleName, Comments
                     });
                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightYellow;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (Status == "DIAG")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVCHECK, date, ModuleName, Comments
                     });
                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightSkyBlue;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }
            }
            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                     {
                         CADD_ANALISIS.Properties.Resources.DGVFAIL, date, "Application log", ex.Message
                     });
                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }

        void WriteLOGS(DateTime date, string ModuleName, string Comments)
        {
            try
            {
                dgvLogs.Rows.Add(new Object[]
                 {
                       date, ModuleName, Comments                 });

                dgvLogs.Rows[dgvLogs.Rows.Count - 1].DefaultCellStyle.BackColor = Color.White;
                dgvLogs.CurrentCell = dgvLogs.Rows[dgvLogs.Rows.Count - 1].Cells[0];
                this.Update();
            }


            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                     {
                         "", date, "Application log", ex.Message
                     });

                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }


        void WriteDGVDiag(string Status, string date, string Tracer, string ModuleName, string Comments)
        {          
            try
            {
                if (Status == "DIAG")
                {
                    dgvDiagnosticPendings.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVFAIL, date, Tracer, ModuleName, Comments
                     });

                    dgvDiagnosticPendings.Rows[dgvDiagnosticPendings.Rows.Count - 1].DefaultCellStyle.BackColor = Color.Red;
                    dgvDiagnosticPendings.CurrentCell = dgvDiagnosticPendings.Rows[dgvDiagnosticPendings.Rows.Count - 1].Cells[0];
                    this.Update();
                }
            }
            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                     {
                         CADD_ANALISIS.Properties.Resources.DGVFAIL, date, "Application log", ex.Message
                     });

                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }


        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            this.Visible = _WindowsState;
            timMonitorProcess.Start();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Administrator admin = new Administrator();
            admin.Show();
        }

        #region USBChecker
        string USBChecker()
        {
            string _Result = "";
            string _RunProg = @"C:\SCO_POS\SCO6\TestExecutables\FindPidVid\devcon.exe";

            try
            {
                Process process = new Process();
                process.StartInfo.FileName = _RunProg;
                process.StartInfo.Arguments = @"find usb\*";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                //process.OutputDataReceived += new DataReceivedEventHandler(OutputHandler);
                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                _Result = output;
            }
            catch (Exception ex)
            {

            }

            return _Result;
        }


        int CheckPIDVID()
        {
            string _Devices = "";
            string _BuildType = File.ReadAllText(@"c:\build.typ");
            int _Result = 0;

            try
            {
                dgvFailures.Rows.Clear();
                _Devices = USBChecker();


                #region CAMERA
                if (_BuildType.Contains("CAMERA") && !_BuildType.Contains("7358-MC115"))
                {            
                    string CAMERA = "CAMERA";
                    string _CAMERA_VP1 = "VID_058F&PID_3822";
                    string _CAMERA_VP2 = "VID_0C45F&PID_6708";
                    string _CAMERA_VP3 = "VID_0C45F&PID_6708&MI_00";

                    if (_Devices.Contains(_CAMERA_VP1) || _Devices.Contains(_CAMERA_VP2) || _Devices.Contains(_CAMERA_VP3))
                    {
                        WriteDGV("GOOD", DateTime.Now, CAMERA + "_VP", _CAMERA_VP1);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, CAMERA, _CAMERA_VP1, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, CAMERA + "_VP", _CAMERA_VP1 + " o " + _CAMERA_VP2 + " o " + _CAMERA_VP3 + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, CAMERA, _CAMERA_VP1 + " o " + _CAMERA_VP2 + " o " + _CAMERA_VP3, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CAMERA_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region UPS_VP
                if (_BuildType.Contains("220V_UPS") || _BuildType.Contains("110V_UPS") || _BuildType.Contains("UPS_110V") || _BuildType.Contains("UPS_220V_NOTAB") || _BuildType.Contains("UPS"))
                {
                    if (!_BuildType.Contains("NO_UPS"))
                    {
                        string UPS = "UPS";
                        string _UPS_VP = "VID_0665&PID_5262";

                        if (_Devices.Contains(_UPS_VP))
                        {
                            WriteDGV("GOOD", DateTime.Now, "UPS_VP", _UPS_VP);
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, UPS, _UPS_VP, CONECTADO);

                        }
                        else
                        {
                            WriteDGV("FAIL", DateTime.Now, "UPS_VP", _UPS_VP + " NO CONECTADO");
                            _Result = _Result + 1;
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, UPS, _UPS_VP, DESCONECTADO);
                        }
                    }                                 
                }
                else
                {
                    WriteLOGS(DateTime.Now, "UPS_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region IOMCU_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && (!_BuildType.Contains("POCONO_BASE"))) //ADD 7358
                {
                    string IOMCU = "IOMCU";
                    string _IOMCU_VP = "VID_0404&PID_0280";

                    if (_Devices.Contains(_IOMCU_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOMCU_VP", _IOMCU_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, IOMCU, _IOMCU_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOMCU_VP", _IOMCU_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, IOMCU, _IOMCU_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOMCU_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region IOHUBA_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE")) //ADD 7358
                {
                    string IOHUBA = "IOHUBA";
                    string _IOHUBA_VP = "VID_0404&PID_034A";

                    if (_Devices.Contains(_IOHUBA_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOHUBA_VP", _IOHUBA_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, IOHUBA, _IOHUBA_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOHUBA_VP", _IOHUBA_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, IOHUBA, _IOHUBA_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOHUBA_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region IOHUBB_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && !_BuildType.Contains("POCONO_BASE")) //ADD 7358
                {
                    string IOHUBB = "IOHUBB";
                    string _IOHUBB_VP = "VID_0404&PID_034B";

                    if (_Devices.Contains(_IOHUBB_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOHUBB_VP", _IOHUBB_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, IOHUBB, _IOHUBB_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOHUBB_VP", _IOHUBB_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, IOHUBB, _IOHUBB_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOHUBB_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region UNAV_VP
                if (_BuildType.Contains("UNAV"))
                {
                    string UNAV = "UNAV";
                    string _UNAV_VP = "VID_0404&PID_0282";

                    if (_Devices.Contains(_UNAV_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "UNAV_VP", _UNAV_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, UNAV, _UNAV_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "UNAV_VP", _UNAV_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, UNAV, _UNAV_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "UNAV_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region BIOMETRIC_VP
                if (_BuildType.Contains("BIOMETRIC"))
                {
                    string BIOMETRIC = "BIOMETRIC";
                    string _BIOMETRIC_VP = "VID_05BA&PID_000A";
                    string _BIOMETRIC_VP_2 = "VID_147E&PID_2016";

                    if (_Devices.Contains(_BIOMETRIC_VP) || _Devices.Contains(_BIOMETRIC_VP_2))
                    {
                        WriteDGV("GOOD", DateTime.Now, "BIOMETRIC_VP", _BIOMETRIC_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, BIOMETRIC, _BIOMETRIC_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "BIOMETRIC_VP", _BIOMETRIC_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, BIOMETRIC, _BIOMETRIC_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "BIOMETRIC_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region TOUCH_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && !_BuildType.Contains("POCONO_BASE")) //ADD 7358
                {
                    string TOUCHVP = "TOUCHVP";
                    string _TOUCH_VP = "VID_2149&PID_1510";
                    string _TOUCH_VP2 = "VID_2149&PID_1810";
                    if (_Devices.Contains(_TOUCH_VP) || _Devices.Contains(_TOUCH_VP2))
                    {
                        WriteDGV("GOOD", DateTime.Now, "TOUCH_VP", _TOUCH_VP + " O " + _TOUCH_VP2);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, TOUCHVP, _TOUCH_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "TOUCH_VP", "NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, TOUCHVP, _TOUCH_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "TOUCH_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region TOUCH_VP_POCONO
                if (_BuildType.Contains("CLASS_7350") && _BuildType.Contains("POCONO_BASE"))
                {
                    string TOUCHVP = "TOUCHVP_POCONO";
                    string _TOUCH_VP = "VID_07DD&PID_0001";
                    if (_Devices.Contains(_TOUCH_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, TOUCHVP, _TOUCH_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, TOUCHVP, "NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "TOUCHVP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region SWIPE_READER_VP
                if (_BuildType.Contains("SWIPE_READER"))
                {
                    string SWIPEREADER = "SWIPEREADER";
                    string _SWIPEREADER_VP = "VID_0801&PID_0011";

                    if (_Devices.Contains(_SWIPEREADER_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SWIPE_READER_VP", _SWIPEREADER_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, SWIPEREADER, _SWIPEREADER_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SWIPE_READER_VP", _SWIPEREADER_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, SWIPEREADER, _SWIPEREADER_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "SWIPE_READER_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region DIP_READER_VP
                if (_BuildType.Contains("DIP"))
                {
                    string DIPREADER = "MSR_SANKYO";
                    string _DIPREADER_VP = "VID_077A&PID_1015";

                    if (_Devices.Contains(_DIPREADER_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "MSR_SANKYO_VP", _DIPREADER_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, DIPREADER, _DIPREADER_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "MSR_SANKYO_VP", _DIPREADER_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, DIPREADER, _DIPREADER_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "DIP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region SCALE_VP
                if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                {
                    string SCALE = "SCALE";
                    string _SCALE_VP = "VID_0404&PID_0225";

                    if (_Devices.Contains(_SCALE_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SCALE_VP", _SCALE_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, SCALE, _SCALE_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SCALE_VP", _SCALE_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, SCALE, _SCALE_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "SCALE_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region REC_PRINTER1S_VP
                if (_BuildType.Contains("REC_PRINTER_1S"))
                {
                    string RECPRINTER1S = "RECPRINTER1S";
                    string _RECPRINTER1S_VP = "VID_0404&PID_0310";

                    if (_Devices.Contains(_RECPRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "REC_PRINTER1S_VP", _RECPRINTER1S_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, RECPRINTER1S, _RECPRINTER1S_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "REC_PRINTER1S_VP", _RECPRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, RECPRINTER1S, _RECPRINTER1S_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "REC_PRINTER_1S", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region REC_PRINTER2S_VP
                if (_BuildType.Contains("REC_PRINTER_2S"))
                {
                    string RECPRINTER2S = "RECPRINTER2S";
                    string _RECPRINTER1S_VP = "VID_0404&PID_0310";

                    if (_Devices.Contains(_RECPRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "REC_PRINTER2S_VP", _RECPRINTER1S_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, RECPRINTER2S, _RECPRINTER1S_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "REC_PRINTER2S_VP", _RECPRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, RECPRINTER2S, _RECPRINTER1S_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "REC_PRINTER2S", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region PRINTER1S_VP
                if (_BuildType.Contains("RECPRINTER_80_1S"))
                {
                    string PRINTER1S = "PRINTER1S";
                    string _PRINTER1S_VP = "VID_0404&PID_0371";

                    if (_Devices.Contains(_PRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "PRINTER1S_VP", _PRINTER1S_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, PRINTER1S, _PRINTER1S_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "PRINTER1S_VP", _PRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, PRINTER1S, _PRINTER1S_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "PRINTER1S_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region PRINTER2S_VP
                if (_BuildType.Contains("RECPRINTER_80_2S"))
                {
                    string PRINTER2S = "PRINTER2S";
                    string _PRINTER2S_VP = ("VID_0404&PID_0374");

                    if (_Devices.Contains(_PRINTER2S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "PRINTER2S_VP", _PRINTER2S_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, PRINTER2S, _PRINTER2S_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "PRINTER2S_VP", _PRINTER2S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, PRINTER2S, _PRINTER2S_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "PRINTER2S_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region CRANE_VP
                if (_BuildType.Contains("CRANE") && !_BuildType.Contains("7358"))
                {
                    string CRANE = "CRANE";
                    string _CRANE_VP = "VID_106F&PID_000C";

                    if (_Devices.Contains(_CRANE_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "CRNAE_VP", _CRANE_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, CRANE, _CRANE_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "CRANE_VP", _CRANE_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, CRANE, _CRANE_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CRANE_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region BCR_MONEYCONTROL_VP
                if (_BuildType.Contains("CRANE") && _BuildType.Contains("7358") || _BuildType.Contains("FASTLANE") && _BuildType.Contains("RECYCLERCOIN") && !_BuildType.Contains("NO_CURR_MODULES"))
                {
                    string BCRMONEYCONTROL = "BCRMONEYCONTROL";
                    string _BCRMONEY_VP = "VID_106F&PID_0003";

                    if (_Devices.Contains(_BCRMONEY_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "BCR_MONEYCONTROL_VP", _BCRMONEY_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, BCRMONEYCONTROL, _BCRMONEY_VP, CONECTADO);

                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "BCR_MONEYCONTROL_VP", _BCRMONEY_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, BCRMONEYCONTROL, _BCRMONEY_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "BCR_MONEYCONTROL_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region MEI-BNR
                if (_BuildType.Contains("CLASS_7350"))
                {
                    if (_BuildType.Contains("GSR50") && _BuildType.Contains("FASTLANE"))
                    {
                        string MEIBNR = "MEIBNR";
                        string _GSR50_VP = "VID_0BED&PID_0A00";

                        if (_Devices.Contains(_GSR50_VP))
                        {
                            WriteDGV("GOOD", DateTime.Now, "MEIBNR_VP", _GSR50_VP);
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, MEIBNR, _GSR50_VP, CONECTADO);
                        }
                        else
                        {
                            WriteDGV("FAIL", DateTime.Now, "MEIBNR_VP", _GSR50_VP + " NO CONECTADO");
                            _Result = _Result + 1;
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, MEIBNR, _GSR50_VP, DESCONECTADO);
                        }
                    }
                    else
                    {
                        WriteLOGS(DateTime.Now, "GSR50", "NO ENCONTRADO EN BUILDTYPE");
                    }
                }

                #endregion

                #region GSR50
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7358"))
                {
                    if (_BuildType.Contains("GSR50"))
                    {
                        string GSR50 = "FUJITSUGSR50";
                        string _GSR50_VP = "VID_04C5&PID_124A";

                        if (_Devices.Contains(_GSR50_VP))
                        {
                            WriteDGV("GOOD", DateTime.Now, "GSR50_VP", _GSR50_VP);
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, GSR50, _GSR50_VP, CONECTADO);
                        }
                        else
                        {
                            WriteDGV("FAIL", DateTime.Now, "GSR50_VP", _GSR50_VP + " NO CONECTADO");
                            _Result = _Result + 1;
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, GSR50, _GSR50_VP, DESCONECTADO);
                        }
                    }
                    else
                    {
                        WriteLOGS(DateTime.Now, "GSR50", "NO ENCONTRADO EN BUILDTYPE");
                    }
                }

                #endregion

                #region FUJISTU F53
                if (_BuildType.Contains("FUJITSU_DISP"))
                {
                    string FUJITSUF53 = "FUJITSU_F53";
                    string _FUJITSUF53_VP = "VID_04C5&PID_1090";

                    if (_Devices.Contains(_FUJITSUF53_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "FUJITSU_F53_VP", _FUJITSUF53_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, FUJITSUF53, _FUJITSUF53_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "FUJITSU_F53_VP", _FUJITSUF53_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, FUJITSUF53, _FUJITSUF53_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "FUJITSU_DISP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region CASHACCEPTOR 
                if (_BuildType.Contains("CASHACCEPT") && _BuildType.Contains("POCONO_BASE"))
                {
                    string SCNCASHACCEPTOR = "SCN_CASH_ACCEPTOR";
                    string _SCNCASHACCEPTOR_VP = "VID_0BED&PID_1100";

                    if (_Devices.Contains(_SCNCASHACCEPTOR_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SCN_CASH_ACCEPTOR_VP", _SCNCASHACCEPTOR_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, SCNCASHACCEPTOR, _SCNCASHACCEPTOR_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SCN_CASH_ACCEPTOR_VP", _SCNCASHACCEPTOR_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, SCNCASHACCEPTOR, _SCNCASHACCEPTOR_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CASHACCEPT", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

            }
            catch (Exception ex)
            {
                WriteDGV("FAIL", DateTime.Now, "CADD-ANALISIS", ex.Message);
                WriteLOGS(DateTime.Now, "CADD-ANALISIS", ex.Message);
            }
            return _Result;
        }
        #endregion

        private void btnAnalizar_Click(object sender, EventArgs e)
        {
            
            //Task.Factory.StartNew(() =>
            //{
                string Progreso = "0%";
                string _SlotInfo = string.Empty;
                string _IpInfo = string.Empty;
                string _OperatorInfo = string.Empty;
                InitReadDiagnosticsPendings(); //fnction to review before to start the test if exists a diagnsotic pending

                try
                {
                    lblProgress.Text = Progreso;

                    TRACER = File.ReadLines(@"c:\build.typ").First();
                    string[] array = { "" };
                    array = getMC.GetSCMC(TRACER);
                    lblTracer.Text = "TRACER: " + TRACER;
                    lblSN.Text = "SERIAL NUMBER: " + array[0];
                    lblClass.Text = "CLASS: " + array[1];
                    lblMC.Text = "MC: " + array[2];

                    RESULTADO = 0;
                    dgvFailures.Rows.Clear();
                    string _BuildType = File.ReadAllText(@"c:\build.typ");
                    btnAnalizar.Enabled = false;
                    this.Update();

                    _ADDEvent.CADDTable();


                    if (array[1] == "7362")
                    {
                        System.Threading.Thread.Sleep(50000);
                    }
                    else
                    {
                        System.Threading.Thread.Sleep(10000);
                    }


                    if (_Class == "7350R5")
                    {
                        PRERESULT = ValidateTracer(TRACER, array[0], array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "3%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckUPS();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "15%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckPrinterREC();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "26%";
                        lblProgress.Text = Progreso;

                        
                        if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                        {
                            PRERESULT = CheckScale();
                            EvalularResultado(PRERESULT);
                        }
                        
                        Progreso = "39%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckBCR();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "58%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckFujitsuF53();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "70%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckSCNCashAcceptor();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "88%";
                        lblProgress.Text = Progreso;
                    }

                    if (_Class == "7350R6Lite")
                    {
                        PRERESULT = ValidateTracer(TRACER, array[0], array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "1%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckDisplayPartNumber(TRACER, array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "2%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckIOBoard();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "17%";
                        lblProgress.Text = Progreso;

                       if (_BuildType.Contains("220V_UPS") || _BuildType.Contains("110V_UPS") || _BuildType.Contains("UPS_110V"))
                       {
                            PRERESULT = CheckUPS();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                       }
                       
                        Progreso = "32%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("DIP"))
                        {
                            PRERESULT = CheckMSR();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }

                        Progreso = "38%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckPrinterREC();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "47%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                        {
                            PRERESULT = CheckScale();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }   
                       
                        Progreso = "71%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckBCR();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "87%";
                        lblProgress.Text = Progreso;
                        
                                           
                        if(_BuildType.Contains("CASHACCEPT")  || _BuildType.Contains("CASH_ACCEPTOR"))
                        {
                          if (!_BuildType.Contains("CASH_RECYCLER"))
                          {
                            PRERESULT = CheckSCNCashAcceptor();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                            
                            Progreso = "89%";
                            lblProgress.Text = Progreso;
                            
                            PRERESULT = CheckFujitsuF53();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                          }
                         
                        }

                       if (_BuildType.Contains("CASH_RECYCLER"))
                       {
                          PRERESULT = CheckMEIBNR();
                          EvalularResultado(PRERESULT);
                          if (RESULTADO != 0) goto TestFail;

                          Progreso = "95%";
                          lblProgress.Text = Progreso;
                       }
                       
                        Progreso = "98%";
                        lblProgress.Text = Progreso;
                    }

                    if (_Class == "7358")
                    {
                        PRERESULT = ValidateTracer(TRACER, array[0], array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "1%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckDisplayPartNumber(TRACER, array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "3%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckIOBoard();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;


                        PRERESULT = CheckTriLight();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "17%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("220V_UPS") || _BuildType.Contains("110V_UPS") || _BuildType.Contains("UPS_110V"))
                        {
                            PRERESULT = CheckUPS();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }
                       
                        PRERESULT = CheckPrinter();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "37%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("DIP"))
                        {
                            PRERESULT = CheckMSR();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }

                        Progreso = "40%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                        {
                            PRERESULT = CheckScale();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }
                        
                        PRERESULT = CheckBCR();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;
                        
                        Progreso = "69%";
                        lblProgress.Text = Progreso;
                        
                        PRERESULT = CheckGSR50();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;
                        
                        Progreso = "97%";
                        lblProgress.Text = Progreso;
                    }

                    if (_Class == "7360")
                    {
                        PRERESULT = ValidateTracer(TRACER, array[0], array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "1%";
                        lblProgress.Text = Progreso;
                       
                        //PRERESULT = CheckDisplayPartNumber(TRACER, array[1], array[2]);
                        //EvalularResultado(PRERESULT);
                        //if (RESULTADO != 0) goto TestFail;

                        Progreso = "3%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckIOBoard();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "25%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckTriLight();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        if (_BuildType.Contains("220V_UPS") || _BuildType.Contains("110V_UPS") || _BuildType.Contains("UPS_110V"))
                        {
                            PRERESULT = CheckUPS();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }
                       
                        Progreso = "39%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckPrinter();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "67%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckGSR50();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "88%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckCRANE();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;
               
                        Progreso = "91%";
                        lblProgress.Text = Progreso;

                        if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                        {
                            PRERESULT = CheckScale();
                            EvalularResultado(PRERESULT);
                            if (RESULTADO != 0) goto TestFail;
                        }
                        
                        Progreso = "99%";
                        lblProgress.Text = Progreso;
                    }

                    if (_Class == "7362")
                    {
                        PRERESULT = ValidateTracer(TRACER, array[0], array[1], array[2]);
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "3%";
                        lblProgress.Text = Progreso;
                 
                        PRERESULT = CheckIOBoard();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "10%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckUPS();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "44%";
                        lblProgress.Text = Progreso;

                        //if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                        //{
                            //PRERESULT = CheckScale();
                            //EvalularResultado(PRERESULT);
                        //}

                        Progreso = "57%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckCRANE();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "78%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckGSR50();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "81%";
                        lblProgress.Text = Progreso;

                        PRERESULT = CheckPrinter();
                        EvalularResultado(PRERESULT);
                        if (RESULTADO != 0) goto TestFail;

                        Progreso = "95%";
                        lblProgress.Text = Progreso;
                    }


                    btnAnalizar.Enabled = true;
                    if (RESULTADO == 0)
                    {
                        btnContinuar.Enabled = true;
                        WriteDGV("GOOD", DateTime.Now, "CADD-ANALISIS", "PROCESO TERMINADO");
                        //_ADDEvent.CreateXMLCADD_START(CADD, TRACER);
                        _ADDEvent.CreateXMLCADD_END(CADD, TRACER);
                        Progreso = "100%";
                        lblProgress.Text = Progreso;

                        //Animacion cuando caddchecker falle paneles cambiana color rojo
                        panel_1.BackColor = Color.LightGreen;
                        panel_2.BackColor = Color.LightGreen;
                        panel_3.BackColor = Color.LightGreen;
                        panel_4.BackColor = Color.LightGreen;
                        lblRunning.Text = "Complete";

                    //Automation Script
                    _automationFlag = iniFiles.reader("CADD_ANALISIS", "CaddChecker", _dirAutomationSettings);
                    if (_automationFlag == "true")
                    {
                        this.Refresh();
                        btnContinuar.Enabled = false;
                        System.Threading.Thread.Sleep(2500);
                        //btnContinuar_Click(sender, e);                       
                        btnContinuar.Enabled = true;
                        beepPass = true;
                        timerBeep.Interval = 1000;
                        timerBeep.Start();
                    }

                    _SlotInfo = GetSlotInfo();
                    //_IpInfo = GetLocalIPAddress();
                    _OperatorInfo = OperatorInfo();
                    ReportingSemaphore("",_OperatorInfo, TRACER, CLASS + MC, _SlotInfo, "", "Pre-Test Cadd-Checker Passed " + DateTime.Now.ToString(), "YELLOW", "16%");
                }

                TestFail: { };
                    if (RESULTADO != 0)
                    {
                        btnCadd.Enabled = true;
                        btnDebug.Enabled = true;
                        btnAnalizar.Enabled = true;
                        WriteDGV("FAIL", DateTime.Now, "CADD-ANALISIS", "FAVOR DE LLAMAR AL TECNICO DE PRUEBAS PARA REVISON DE UUT");
                        _ADDEvent.CreateXMLCADD_START(CADD, TRACER);
                        Progreso = "100%";
                        lblProgress.Text = Progreso;

                        //Animacion cuando caddchecker falle paneles cambiana color rojo
                        panel_1.BackColor = Color.Red;
                        panel_2.BackColor = Color.Red;
                        panel_3.BackColor = Color.Red;
                        panel_4.BackColor = Color.Red;                       
                        lblRunning.Text = "Complete";
                        beepFail = true;
                        timerBeep.Interval = 3000;
                        timerBeep.Start();

                    _SlotInfo = GetSlotInfo();
                    //_IpInfo = GetLocalIPAddress();
                    _OperatorInfo = OperatorInfo();
                    ReportingSemaphore("",_OperatorInfo, TRACER, CLASS + MC, _SlotInfo, "", "Pre-Test Cadd-Checker Failed " + DateTime.Now.ToString(), "RED", "16%");
                }
                    //dgvFailures.Sort(dgvFailures.Columns[0], ListSortDirection.Ascending);           
                    WriteLOGS(DateTime.Now, "CADD-ANALISIS", "PROCESO TERMINADO");
                }
                catch (Exception ex)
                {
                    WriteDGV("ISSUE", DateTime.Now, "CADD-ANALISIS", ex.Message);
                }
            //});   
        }


        private void btnContinuar_Click(object sender, EventArgs e)
        {
            timerBeep.Stop();
            this.TopMost = true;             
            dgvFailures.Rows.Clear();
            dgvLogs.Rows.Clear();
            this.Refresh();
            this.WindowState = FormWindowState.Maximized;
            this.Visible = false;
            timMonitorProcess.Start();
        }

        private void btnCadd_Click(object sender, EventArgs e)
        {
            try
            {
                btnCadd.Enabled = false;
                Process _process = new Process();
                _process.StartInfo.FileName = @"C:\scot\bin\ADD.bat";
                _process.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
                _process.Start();

                //STEP 1 PROCESO CADD
                WriteLOGS(DateTime.Now, "CADDCONFIG", "EJECUTANDOSE...");

                _process.WaitForExit();

                //STEP 2 PROCESO CADD
                WriteLOGS(DateTime.Now, "CADDCONFIG", "FINALIZADO");
                btnCadd.Enabled = true;
            }
            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                    {
                         "", DateTime.Now, "Application log", ex.Message
                    });

                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }

        private void btnUSBChecker_Click(object sender, EventArgs e)
        {
            try
            {
                int flag = 0;
                string _SlotInfo = string.Empty;               
                string _IpInfo = string.Empty;               
                string _OperatorInfo = string.Empty;               
                TRACER = File.ReadLines(@"c:\build.typ").First();
                string[] array = { "" };
                array = getMC.GetSCMC(TRACER);
                lblTracer.Text = "TRACER: " + TRACER;
                lblSN.Text = "SERIAL NUMBER: " + array[0];
                lblClass.Text = "CLASS: " + array[1];
                lblMC.Text = "MC: " + array[2];

                _ADDEvent.USBTable();

                RESULTADO = 0;
                dgvFailures.Rows.Clear();
                btnUSBChecker.Enabled = false;
                RESULTADO = CheckPIDVID();

                if (RESULTADO == 0)
                {
                    btnContinuar.Enabled = true;
                    WriteDGV("GOOD", DateTime.Now, "USB-CHECKER", "PROCESO TERMINADO");
                    WriteLOGS(DateTime.Now, "USB-CHECKER", "PROCESO TERMINADO");
                    _ADDEvent.CreateXML_START("USBCHECKER_START", TRACER);
                    _ADDEvent.CreateXML_END("USBCHECKER_START", TRACER);

                    _SlotInfo = GetSlotInfo();
                    //_IpInfo = GetLocalIPAddress();
                    _OperatorInfo = OperatorInfo();
                    ReportingSemaphore("",_OperatorInfo, TRACER, CLASS + MC, _SlotInfo, _IpInfo, "Pre-Test Usb-Checker Passed " + DateTime.Now.ToString(), "YELLOW", "2%");
                    System.Threading.Thread.Sleep(500);
                    
                    //Automation Script
                    _automationFlag = iniFiles.reader("CADD_ANALISIS", "UsbChecker", _dirAutomationSettings);
                    if (_automationFlag == "true")
                    {
                        this.Refresh();
                        btnContinuar.Enabled = false;
                        System.Threading.Thread.Sleep(2500);

                        string _StartTest = iniFiles.reader("Pangaea", "StartTest", _dirAutomationSettings);
                        if(_StartTest == "true")
                        {
                            this.WindowState = FormWindowState.Minimized;
                            this.Refresh();
                            AutoItX.WinActivate("Pangaea Financial 1.8.0.0");
                            AutoItX.Sleep(200);
                            AutoItX.Send("{TAB}");
                            AutoItX.Send("{TAB}");
                            AutoItX.Send("{ENTER}");
                        }                                        
                        btnContinuar_Click(sender, e);
                    }


                }
                if (RESULTADO != 0)
                {
                    btnCadd.Enabled = true;
                    WriteDGV("FAIL", DateTime.Now, "CADD-ANALISIS", "FAVOR DE LLAMAR AL TECNICO DE PRUEBAS PARA REVISON DE UUT");
                    timer1.Start();
                    _ADDEvent.CreateXML_START("USBCHECKER_START", TRACER);


                    _SlotInfo = GetSlotInfo();
                    //_IpInfo =GetLocalIPAddress();
                    _OperatorInfo = OperatorInfo();
                    ReportingSemaphore("",_OperatorInfo, TRACER, CLASS + MC, _SlotInfo, _IpInfo, "Pre-Test Usb-Checker Failed " + DateTime.Now.ToString(), "RED", "2%");
                }
                //btnUSBChecker.Enabled = true;
            }
            catch (Exception ex)
            {
                WriteDGV("FAIL", DateTime.Now, "CADD-ANALISIS", ex.Message);
            }
        }

        void ReportingSemaphore(string START_TIME,string OPERATOR, string TRACER, string CLASSMC, string SlotID, string IpAdress, string STATUS, string COLOR, string PROGRESS)
        {
            reportingSem = new CADD_ANALISIS.ReportingSem();
            reportingSem.XMLSSCO();
            reportingSem.CreateXML(START_TIME, OPERATOR, TRACER, CLASSMC, SlotID, IpAdress, STATUS, COLOR, PROGRESS);
        }

        string GetSlotInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            return _unitInfo[3];
        }

        string OperatorInfo()
        {
            DirectoryInfo _dirInfo = new DirectoryInfo(@"C:\JABIL\UnitInfo\");
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);
            return _unitInfo[1] + "-" + _unitInfo[2];
        }

        string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }

            throw new Exception("No network adapters with an IPv4 address in the system!");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            RESULTADO = CheckPIDVIDNoReport();

            if (RESULTADO == 0)
            {
                timer1.Stop();
                _ADDEvent.USBTable();
                CheckPIDVID();
                _ADDEvent.CreateXML_END("USBCHECKER_END", TRACER);
                btnContinuar.Enabled = true;
            }
        }

        int CheckPIDVIDNoReport()
        {
            string _Devices = "";
            string _BuildType = File.ReadAllText(@"c:\build.typ");
            int _Result = 0;

            try
            {
                dgvFailures.Rows.Clear();
                _Devices = USBChecker();

                #region CAMERA
                if (_BuildType.Contains("CAMERA") && !_BuildType.Contains("7358-MC115"))
                {
                    string CAMERA = "CAMERA";
                    string _CAMERA_VP1 = "VID_058F&PID_3822";
                    string _CAMERA_VP2 = "VID_0C45F&PID_6708";
                    string _CAMERA_VP3 = "VID_0C45F&PID_6708&MI_00";

                    if (_Devices.Contains(_CAMERA_VP1) || _Devices.Contains(_CAMERA_VP2) || _Devices.Contains(_CAMERA_VP3))
                    {
                        WriteDGV("GOOD", DateTime.Now, CAMERA + "_VP", _CAMERA_VP1);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, CAMERA, _CAMERA_VP1 + " o " + _CAMERA_VP2 + " o " + _CAMERA_VP3, DESCONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, CAMERA + "_VP", _CAMERA_VP1 + " o " + _CAMERA_VP2 + " o " + _CAMERA_VP3 + " NO CONECTADO");
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CAMERA_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region UPS_VP
                if (_BuildType.Contains("220V_UPS") || _BuildType.Contains("110V_UPS") || _BuildType.Contains("UPS_110V") || _BuildType.Contains("UPS_220V_NOTAB") || _BuildType.Contains("UPS"))
                {
                    if (!_BuildType.Contains("NO_UPS"))
                    {
                        string UPS = "UPS";
                        string _UPS_VP = "VID_0665&PID_5262";

                        if (_Devices.Contains(_UPS_VP))
                        {
                            WriteDGV("GOOD", DateTime.Now, "UPS_VP", _UPS_VP);
                        }
                        else
                        {
                            WriteDGV("FAIL", DateTime.Now, "UPS_VP", _UPS_VP + " NO CONECTADO");
                            _Result = _Result + 1;
                        }
                    }      
                }
                else
                {
                    WriteLOGS(DateTime.Now, "UPS_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region IOMCU_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && (!_BuildType.Contains("POCONO_BASE")))
                {
                    string IOMCU = "IOMCU";
                    string _IOMCU_VP = "VID_0404&PID_0280";

                    if (_Devices.Contains(_IOMCU_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOMCU_VP", _IOMCU_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOMCU_VP", _IOMCU_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOMCU_VP", "NO ENCONTRADO EN BUILTYPE");
                }
                #endregion

                #region IOHUBA_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("FASTLANE"))
                {
                    string IOHUBA = "IOHUBA";
                    string _IOHUBA_VP = "VID_0404&PID_034A";

                    if (_Devices.Contains(_IOHUBA_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOHUBA_VP", _IOHUBA_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOHUBA_VP", _IOHUBA_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOHUBA_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region IOHUBB_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && !_BuildType.Contains("POCONO_BASE"))
                {
                    string IOHUBB = "IOHUBB";
                    string _IOHUBB_VP = "VID_0404&PID_034B";

                    if (_Devices.Contains(_IOHUBB_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "IOHUBB_VP", _IOHUBB_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "IOHUBB_VP", _IOHUBB_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "IOHUBB_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region UNAV_VP
                if (_BuildType.Contains("UNAV"))
                {
                    string UNAV = "UNAV";
                    string _UNAV_VP = "VID_0404&PID_0282";

                    if (_Devices.Contains(_UNAV_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "UNAV_VP", _UNAV_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "UNAV_VP", _UNAV_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "UNAV_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region BIOMETRIC_VP
                if (_BuildType.Contains("BIOMETRIC"))
                {
                    string BIOMETRIC = "BIOMETRIC";
                    string _BIOMETRIC_VP = "VID_05BA&PID_000A";
                    string _BIOMETRIC_VP_2 = "VID_147E&PID_2016";

                    if (_Devices.Contains(_BIOMETRIC_VP) || _Devices.Contains(_BIOMETRIC_VP_2))
                    {
                        WriteDGV("GOOD", DateTime.Now, "BIOMETRIC_VP", _BIOMETRIC_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "BIOMETRIC_VP", _BIOMETRIC_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "BIOMETRIC_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region TOUCH_VP
                if (_BuildType.Contains("CLASS_7360") || _BuildType.Contains("CLASS_7362") || _BuildType.Contains("CLASS_7358") || _BuildType.Contains("FASTLANE") && !_BuildType.Contains("POCONO_BASE"))
                {
                    string TOUCHVP = "TOUCHVP";
                    string _TOUCH_VP = "VID_2149&PID_1510";
                    string _TOUCH_VP2 = "VID_2149&PID_1810";
                    if (_Devices.Contains(_TOUCH_VP) || _Devices.Contains(_TOUCH_VP2))
                    {
                        WriteDGV("GOOD", DateTime.Now, "TOUCH_VP", _TOUCH_VP + " O " + _TOUCH_VP2);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "TOUCH_VP", "NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "TOUCH_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region TOUCH_VP_POCONO
                if (_BuildType.Contains("CLASS_7350") && _BuildType.Contains("POCONO_BASE"))
                {
                    string TOUCHVP = "TOUCHVP_POCONO";
                    string _TOUCH_VP = "VID_07DD&PID_0001";
                    if (_Devices.Contains(_TOUCH_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "TOUCH_VP", _TOUCH_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "TOUCH_VP", "NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "TOUCH_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region SWIPE_READER_VP
                if (_BuildType.Contains("SWIPE_READER"))
                {
                    string SWIPEREADER = "SWIPEREADER";
                    string _SWIPEREADER_VP = "VID_0801&PID_0011";

                    if (_Devices.Contains(_SWIPEREADER_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SWIPE_READER_VP", _SWIPEREADER_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SWIPE_READER_VP", _SWIPEREADER_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "SWIPE_READER_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region DIP_READER_VP
                if (_BuildType.Contains("DIP"))
                {
                    string DIPREADER = "MSR_SANKYO";
                    string _DIPREADER_VP = "VID_077A&PID_1015";

                    if (_Devices.Contains(_DIPREADER_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "MSR_SANKYO_VP", _DIPREADER_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, DIPREADER, _DIPREADER_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "MSR_SANKYO_VP", _DIPREADER_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, DIPREADER, _DIPREADER_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "DIP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region SCALE_VP
                if (_BuildType.Contains("SCALE") && !_BuildType.Contains("NO_SCALE"))
                {
                    string SCALE = "SCALE";
                    string _SCALE_VP = "VID_0404&PID_0225";

                    if (_Devices.Contains(_SCALE_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SCALE_VP", _SCALE_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SCALE_VP", _SCALE_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "SCALE_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region REC_PRINTER1S_VP
                if (_BuildType.Contains("REC_PRINTER_1S"))
                {
                    string RECPRINTER1S = "RECPRINTER1S";
                    string _RECPRINTER1S_VP = "VID_0404&PID_0310";

                    if (_Devices.Contains(_RECPRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "REC_PRINTER1S_VP", _RECPRINTER1S_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "REC_PRINTER1S_VP", _RECPRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "REC_PRINTER_1S", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region REC_PRINTER2S_VP
                if (_BuildType.Contains("REC_PRINTER_2S"))
                {
                    string RECPRINTER2S = "RECPRINTER2S";
                    string _RECPRINTER1S_VP = "VID_0404&PID_0310";

                    if (_Devices.Contains(_RECPRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "REC_PRINTER2S_VP", _RECPRINTER1S_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "REC_PRINTER2S_VP", _RECPRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "REC_PRINTER2S", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region PRINTER1S_VP
                if (_BuildType.Contains("RECPRINTER_80_1S"))
                {
                    string PRINTER1S = "PRINTER1S";
                    string _PRINTER1S_VP = "VID_0404&PID_0371";

                    if (_Devices.Contains(_PRINTER1S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "PRINTER1S_VP", _PRINTER1S_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "PRINTER1S_VP", _PRINTER1S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "PRINTER1S_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region PRINTER2S_VP
                if (_BuildType.Contains("RECPRINTER_80_2S"))
                {
                    string PRINTER2S = "PRINTER2S";
                    string _PRINTER2S_VP = ("VID_0404&PID_0374");

                    if (_Devices.Contains(_PRINTER2S_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "PRINTER2S_VP", _PRINTER2S_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "PRINTER2S_VP", _PRINTER2S_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "PRINTER2S_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region CRANE_VP
                if (_BuildType.Contains("CRANE") && !_BuildType.Contains("7358"))
                {
                    string CRANE = "CRANE";
                    string _CRANE_VP = "VID_106F&PID_000C";

                    if (_Devices.Contains(_CRANE_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "CRNAE_VP", _CRANE_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "CRANE_VP", _CRANE_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CRANE_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region BCR_MONEYCONTROL_VP
                if (_BuildType.Contains("CRANE") && _BuildType.Contains("7358") || _BuildType.Contains("FASTLANE") && _BuildType.Contains("RECYCLERCOIN"))
                {
                    string BCRMONEYCONTROL = "BCRMONEYCONTROL";
                    string _BCRMONEY_VP = "VID_106F&PID_0003";

                    if (_Devices.Contains(_BCRMONEY_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "BCR_MONEYCONTROL_VP", _BCRMONEY_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "BCR_MONEYCONTROL_VP", _BCRMONEY_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "BCR_MONEYCONTROL_VP", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion
       
                #region MEI-BNR
                if (_BuildType.Contains("CLASS_7350"))
                {
                    if (_BuildType.Contains("GSR50") && _BuildType.Contains("FASTLANE"))
                    {
                        string MEIBNR = "MEIBNR";
                        string _GSR50_VP = "VID_0BED&PID_0A00";

                        if (_Devices.Contains(_GSR50_VP))
                        {
                            WriteDGV("GOOD", DateTime.Now, "MEIBNR_VP", _GSR50_VP);
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, MEIBNR, _GSR50_VP, CONECTADO);
                        }
                        else
                        {
                            WriteDGV("FAIL", DateTime.Now, "MEIBNR_VP", _GSR50_VP + " NO CONECTADO");
                            _Result = _Result + 1;
                            _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, MEIBNR, _GSR50_VP, DESCONECTADO);
                        }
                    }
                    else
                    {
                        WriteLOGS(DateTime.Now, "GSR50", "NO ENCONTRADO EN BUILDTYPE");
                    }
                }
                #endregion

                #region GSR50
                if (_BuildType.Contains("GSR50") && !_BuildType.Contains("FASTLANE"))
                {
                    string GSR50 = "FUJITSUGSR50";
                    string _GSR50_VP = "VID_04C5&PID_124A";

                    if (_Devices.Contains(_GSR50_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "GSR50_VP", _GSR50_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "GSR50_VP", _GSR50_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "GSR50", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region FUJISTU F53
                if (_BuildType.Contains("FUJITSU_DISP"))
                {
                    string FUJITSUF53 = "FUJITSU_F53";
                    string _FUJITSUF53_VP = "VID_04C5&PID_1090";

                    if (_Devices.Contains(_FUJITSUF53_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "FUJITSU_F53_VP", _FUJITSUF53_VP);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "FUJITSU_F53_VP", _FUJITSUF53_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "GSR50", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion

                #region CASHACCEPTOR 
                if (_BuildType.Contains("CASHACCEPT") && _BuildType.Contains("POCONO_BASE"))
                {
                    string SCNCASHACCEPTOR = "SCN_CASH_ACCEPTOR";
                    string _SCNCASHACCEPTOR_VP = "VID_0BED&PID_1100";

                    if (_Devices.Contains(_SCNCASHACCEPTOR_VP))
                    {
                        WriteDGV("GOOD", DateTime.Now, "SCN_CASH_ACCEPTOR_VP", _SCNCASHACCEPTOR_VP);
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, PASS, SCNCASHACCEPTOR, _SCNCASHACCEPTOR_VP, CONECTADO);
                    }
                    else
                    {
                        WriteDGV("FAIL", DateTime.Now, "SCN_CASH_ACCEPTOR_VP", _SCNCASHACCEPTOR_VP + " NO CONECTADO");
                        _Result = _Result + 1;
                        _ADDEvent.AddInfoTable(DateTime.Now, TRACER, FAIL, SCNCASHACCEPTOR, _SCNCASHACCEPTOR_VP, DESCONECTADO);
                    }
                }
                else
                {
                    WriteLOGS(DateTime.Now, "CASHACCEPT", "NO ENCONTRADO EN BUILDTYPE");
                }
                #endregion
            }
            catch (Exception ex)
            {
                WriteDGV("FAIL", DateTime.Now, "CADD-ANALISIS", ex.Message);
                WriteLOGS(DateTime.Now, "CADD-ANALISIS", ex.Message);
            }
            return _Result;
        }

        #region Debug Mode:
        private void btnDebug_Click(object sender, EventArgs e)
        {
            // tabControl1.Visible = true;
            // this.TopMost = false;

            try
            {
                WriteLOGS(DateTime.Now, "GET DIAG FILES", "GETTING DIAG FILES...");
                ExternalExe(@"c:\scot\bin\GetDiagFiles.exe", "");
                string PathFailures = @"C:\JABIL\FAILURES\";
                DirectoryInfo dicInfo = new DirectoryInfo(@"C:\temp\");
                DirectoryInfo dicInfoFailure = new DirectoryInfo(PathFailures);
                FileInfo[] diagnosticsPendings = dicInfoFailure.GetFiles("*.txt");                
                FileInfo[] files = dicInfo.GetFiles("*.zip");

                string[] moduleName = File.ReadAllLines(diagnosticsPendings[0].FullName);

               
                foreach (FileInfo file in files)
                {
                    File.Copy(file.FullName, @"\\mxchim0pangea01\Test_docs\SSCO\JIRA\" + moduleName[2] + "_" + file.Name);
                    WriteLOGS(DateTime.Now, "COPYING " + file.Name + "...", @"\\mxchim0pangea01\Test_docs\SSCO\JIRA\" + moduleName[2] + "_" + file.Name );
                }

                WriteLOGS(DateTime.Now, "GET DIAG FILES", "DONE!");
            }
            catch(Exception ex)
            {
                WriteDGV("FAIL", DateTime.Now, "Application error", ex.Message);
            }     
        }

        private void btnChkIOBOARD_Click(object sender, EventArgs e)
        {
            CheckIOBoard();
        }

        private void btnRLogsIOBOARD_Click(object sender, EventArgs e)
        {
            string _moduleName = "IO BOARD";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_MiscIF_NCR_DigitalInterface_USB.dat";
                string _Log = @"c:\scot\logs\CADD_MiscIF_NCR_DigitalInterface.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnFlashIOBOARD_Click(object sender, EventArgs e)
        {
            string _moduleName = "IO BOARD";

            try
            {
                this.TopMost = false;

                string _prog = @"c:\scot\devices\MiscIF\NCR_DigitalInterface\Firmware\RomFlasher\RomFlasher.exe";

                Process process = new Process();
                process.StartInfo.FileName = _prog;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _prog);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkSCALE_Click(object sender, EventArgs e)
        {
            CheckScale();
        }

        private void btnRLogsSCALE_Click(object sender, EventArgs e)
        {
            string _moduleName = "SCALE";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_Scale_NCR_Bag_USB.dat";
                string _Log = @"c:\scot\logs\CADD_Scale_NCR_Bag.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnCalibrate_Click(object sender, EventArgs e)
        {
            string _moduleName = "SCALE";

            try
            {
                this.TopMost = false;

                //string _prog = @"c:\JABIL\Scale calibration.exe";
                string _prog = @"c:\scot\devices\Scale\NCR_Bag\Firmware\NCRScaleTestUtil.exe";

                Process process = new Process();
                process.StartInfo.FileName = _prog;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _prog);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkGSR50_Click(object sender, EventArgs e)
        {
            CheckGSR50();
        }

        private void btnRLogsGSR50_Click(object sender, EventArgs e)
        {
            string _moduleName = "GSR50";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_CashChanger_Fujitsu_GSR50_USB.dat";
                string _Log = @"c:\scot\logs\CADD_CashChanger_Fujitsu_GSR50.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkCR5000_Click(object sender, EventArgs e)
        {
            CheckCRANE();
        }

        private void btnRLogsCR5000_Click(object sender, EventArgs e)
        {
            string _moduleName = "CR5000";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_CashChanger_Crane_Xchange_USB.dat";
                string _Log = @"c:\scot\logs\CADD_CashChanger_Crane_Xchange.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkPRINTER_Click(object sender, EventArgs e)
        {
            CheckPrinter();
        }

        private void btnRLogsPRINTER_Click(object sender, EventArgs e)
        {
            string _moduleName = "PRINTER";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_POSPrinter_NCR_HIDReceipt_USB.dat";
                string _Log = @"c:\scot\logs\CADD_POSPrinter_NCR_HIDReceipt.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnActiveNCRLOADER_Click(object sender, EventArgs e)
        {
            string _moduleName = "PRINTER";
            try
            {
                string _ServiceName = "NCRLoader";
                ServiceController _Service = new ServiceController(_ServiceName);
                int timeoutMilisegundos = 40000;

                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilisegundos);

                if (_Service.Status == ServiceControllerStatus.Stopped)
                {
                    _Service.Start();
                    _Service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                    WriteLOGS(DateTime.Now, _moduleName, "Initialized Service");
                }
                else
                {
                    WriteLOGS(DateTime.Now, _moduleName, "Service already active");
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnFlashPRINTER_Click(object sender, EventArgs e)
        {
            string _moduleName = "PRINTER";

            try
            {
                this.TopMost = false;
                string _prog = @"c:\scot\devices\POSPrinter\NCR_HIDReceipt\Firmware\TseFlash.com";
                //string _args = @"/SSCO6-1ST/2ST /m /CPMI /c:\scot\devices\POSPrinter\NCR_HIDReceipt\Firmware\7360\SCCO6_MAIN_V6162.mfw /noskip /print";
                Process process = new Process();
                process.StartInfo.FileName = _prog;
                //process.StartInfo.Arguments = _args;
                //process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();
                WriteLOGS(DateTime.Now, _moduleName, _prog);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkRECPRINTER_Click(object sender, EventArgs e)
        {
            CheckPrinterREC();
        }

        private void btnRLogsRECPRINTER_Click(object sender, EventArgs e)
        {
            string _moduleName = "REC PRINTER";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_POSPrinter_NCR_HIDReceipt_USB.dat";
                string _Log = @"c:\scot\logs\CADD_POSPrinter_NCR_HIDReceipt.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnActivateNCRLOADER2_Click(object sender, EventArgs e)
        {
            string _moduleName = "REC PRINTER";
            try
            {
                string _ServiceName = "NCRLoader";
                ServiceController _Service = new ServiceController(_ServiceName);
                int timeoutMilisegundos = 40000;

                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilisegundos);

                if (_Service.Status == ServiceControllerStatus.Stopped)
                {
                    _Service.Start();
                    _Service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                    WriteLOGS(DateTime.Now, _moduleName, "Initialized Service");
                }
                else
                {
                    WriteLOGS(DateTime.Now, _moduleName, "Service already active");
                }
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnFlashRECPRINTER_Click(object sender, EventArgs e)
        {
            string _moduleName = "PRINTER";

            try
            {
                this.TopMost = false;

                string _prog = @"c:\\\mxchim0pangea01\SSCO_IMAGES\7360R6_TESTIMAGE.wim\2\scot\devices\POSPrinter\NCR_Receipt\Firmware\TseFlash.exe";

                Process process = new Process();
                process.StartInfo.FileName = _prog;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _prog);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkBCR_Click(object sender, EventArgs e)
        {
            CheckBCR();
        }

        private void btnRLogsBCR_Click(object sender, EventArgs e)
        {
            string _moduleName = "BCR MONEYCONTROL";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_CashChanger_MoneyControls_BCR_USB.dat";
                string _Log = @"c:\scot\logs\CADD_CashChanger_MoneyControls_BCR.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkBNR_Click(object sender, EventArgs e)
        {
            CheckMEIBNR();
        }

        private void btnRLogsBNR_Click(object sender, EventArgs e)
        {
            string _moduleName = "MEI BNR";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\";
                string _Log = @"c:\scot\logs\";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnChkCashAccept_Click(object sender, EventArgs e)
        {
            CheckSCNCashAcceptor();
        }

        private void btnRLogsCashAccept_Click(object sender, EventArgs e)
        {
            string _moduleName = "SCN CASH ACCEPT";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\logs\ADDFW_CashAcceptor_MEI_ZT_SC_USB.dat";
                string _Log = @"c:\scot\logs\CADD_CashAcceptor_MEI_ZT_SC.log";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();

                WriteLOGS(DateTime.Now, _moduleName, _dat);

                process.StartInfo.FileName = _Log;
                process.Start();
                WriteLOGS(DateTime.Now, _moduleName, _Log);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        private void btnPML_Click(object sender, EventArgs e)
        {
            string _moduleName = "PML";
            string HWType = "";
            //string _prog = @"c:\testTools\pml.bat";
            string _prog = @"c:\scot\bin\ProfileManagerLite.exe";
            string _configFile = @"C:\Scot\config\caddopts.001";

            try
            {
                this.TopMost = false;
                CADD_ANALISIS.IniFiles _iniFiles = new CADD_ANALISIS.IniFiles();           
                HWType = _iniFiles.reader("Hardware", "HWType", _configFile);
                if (HWType != "SCOT5") _iniFiles.write("Hardware", "HWType", "SCOT5", _configFile);
                System.Threading.Thread.Sleep(500);
                Process process = new Process();
                process.StartInfo.FileName = _prog;
                process.StartInfo.Arguments = "/nodongle";
                process.Start();
                System.Threading.Thread.Sleep(5000);
                if (HWType == "SCOT6") _iniFiles.write("Hardware", "HWType", HWType, _configFile);

                WriteLOGS(DateTime.Now, _moduleName, _prog);
            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }

        private void btnCaddOpts_Click(object sender, EventArgs e)
        {
            string _moduleName = "CADDOPTS.001";

            try
            {
                this.TopMost = false;

                string _dat = @"c:\scot\config\CADDOPTS.001";

                Process process = new Process();
                process.StartInfo.FileName = _dat;
                process.Start();

                WriteLOGS(DateTime.Now, _moduleName, _dat);

            }
            catch (Exception ex)
            {
                WriteLOGS(DateTime.Now, _moduleName, ex.Message);
            }
        }


        string ArrayFeats(string CLASE, string MC)
        {
            string RESULTADO = "";

            StreamReader _sReader = new StreamReader(@"\\mxchim0pangea01\diskbld\feats\Feat" + CLASE);
            int length = 15;

            try
            {
                while (!_sReader.EndOfStream)
                {
                    string x = _sReader.ReadLine();
                    string[] arreglo = x.Split(' ');

                    //10023261 
                    if (arreglo[0].Contains(CLASE + "-MC" + MC.ToUpper()) == true)
                    {
                        int i = length - arreglo[0].Length;
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return RESULTADO;
        }

        private void btnEboxTest_Click(object sender, EventArgs e)
        {
            try
            {
                string _RecursoIfactory = string.Empty;
                string _StepNameIfactory = string.Empty;

                if (_Class == "7350R5")
                {
                     _RecursoIfactory = "RECURSO:SEBOX01TE01"; //Recurso para dar el pass en iFactory
                     _StepNameIfactory = "STEPNAME:EBOX TEST"; //Nombre del step en iFactory
                }

                if (_Class == "7350R6Lite" || _Class == "7360" || _Class == "7358")
                {
                    // _RecursoIfactory = "RECURSO:SEBOX01TE01"; //Recurso para dar el pass en iFactory
                    // _StepNameIfactory = "STEPNAME:XR7 TEST"; //Nombre del step en iFactory
                    _RecursoIfactory = "RECURSO:SEBOX01TE01"; //Recurso para dar el pass en iFactory
                    _StepNameIfactory = "STEPNAME:EBOX TEST"; //Nombre del step en iFactory
                }


                TRACER = File.ReadLines(@"c:\build.typ").First();
                string[] array = { "" };
                array = getMC.GetSCMC(TRACER);
                lblTracer.Text = "TRACER: " + TRACER;
                lblSN.Text = "SERIAL NUMBER: " + array[0];
                lblClass.Text = "CLASS: " + array[1];
                lblMC.Text = "MC: " + array[2];

                RESULTADO = 0;
                dgvFailures.Rows.Clear();
                string _BuildType = File.ReadAllText(@"c:\build.typ");
                btnEboxTest.Enabled = false;
                this.Update();
                _ADDEvent.EBOXTable();

                if (_Class != "7362")
                {
                    PRERESULT = CheckRAMTest();
                    EvalularResultado(PRERESULT);

                    PRERESULT = CheckCPUTest();
                    EvalularResultado(PRERESULT);

                    if (_BuildType.Contains("TPM_2.0"))
                    {
                        PRERESULT = TPM20Test();
                        EvalularResultado(PRERESULT);
                    }
                }
           
                _ADDEvent.AddInfoEBOXTable(DateTime.Now, TRACER, "iFactory", _RecursoIfactory, _StepNameIfactory);

                if (RESULTADO == 0)
                {
                    btnContinuar.Enabled = true;
                    WriteDGV("GOOD", DateTime.Now, EBOX, "PROCESO TERMINADO");
                    _ADDEvent.CreateXML_EBOXTest(EBOX, TRACER);
                }
                if (RESULTADO != 0)
                {
                    btnEboxTest.Enabled = true;
                    WriteDGV("FAIL", DateTime.Now, EBOX, "FAVOR DE LLAMAR AL TECNICO DE PRUEBAS PARA REVISON DE UUT");
                    _ADDEvent.CreateXML_EBOXTest(EBOX, TRACER);
                }
            }
            catch (Exception ex)
            {
                WriteDGV("ISSUE", DateTime.Now, EBOX, ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Administrator admin = new Administrator();
            //admin.Show();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        bool beepFail = false;
        bool beepPass = false;
        private void timerBeep_Tick(object sender, EventArgs e)
        {
            VolUp();

            if (beepPass)
            {
                SoundPlayer beep = new SoundPlayer(CADD_ANALISIS.Properties.Resources.FAIL_BEEP);
                beep.Play();
            }

            if (beepFail)
            {
                SoundPlayer beep = new SoundPlayer(CADD_ANALISIS.Properties.Resources.FAIL_BEEP);
                beep.Play();
            }
        }

        private void dgvFailures_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    } 

    #endregion
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CADD_ANALISIS
{
    public partial class DebugMode : Form
    {
        public DebugMode()
        {
            InitializeComponent();        
        }

      
        void InicializarDataGridView()
        {
            //dgvFailures.Columns.Add("status", "Status");
            dgvFailures.Columns.Add("date", "Fecha");
            dgvFailures.Columns.Add("buildtype", "Imagen correcta");
            dgvFailures.Columns.Add("imagen", "Imagen conectada");

            //dgvFailures.Columns["status"].Width = 60;
            dgvFailures.Columns["date"].Width = 125;
            dgvFailures.Columns["buildtype"].Width = 150;
            dgvFailures.Columns["imagen"].Width = 400;
            dgvFailures.RowHeadersVisible = false;
        }
      
        void WriteDGV(string Status, DateTime date, string ModuleName, string Comments)
        {
            try
            {
                if (Status == "FAIL")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVFAIL, date, ModuleName, Comments
                     });


                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.Red;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (Status == "GOOD")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVGOOD, date, ModuleName, Comments
                     });

                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightGreen;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }

                if (Status == "CHECK")
                {
                    dgvFailures.Rows.Add(new Object[]
                     {
                           CADD_ANALISIS.Properties.Resources.DGVCHECK, date, ModuleName, Comments
                     });

                    dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LightYellow;
                    dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                    this.Update();
                }

            }

            catch (Exception ex)
            {
                dgvFailures.Rows.Add(new Object[]
                     {
                         CADD_ANALISIS.Properties.Resources.DGVFAIL, date, "Application log", ex.Message
                     });

                dgvFailures.Rows[dgvFailures.Rows.Count - 1].DefaultCellStyle.BackColor = Color.PaleVioletRed;
                dgvFailures.CurrentCell = dgvFailures.Rows[dgvFailures.Rows.Count - 1].Cells[0];
                this.Update();
            }
        }

        private void btnContinuar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

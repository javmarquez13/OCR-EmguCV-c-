﻿namespace FixR6LitePrinter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.dgvFailures = new System.Windows.Forms.DataGridView();
            this.PassFail = new System.Windows.Forms.DataGridViewImageColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAnalizar = new System.Windows.Forms.Button();
            this.btnContinuar = new System.Windows.Forms.Button();
            this.btnCadd = new System.Windows.Forms.Button();
            this.dgvLogs = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnUSBChecker = new System.Windows.Forms.Button();
            this.lblTracer = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblMC = new System.Windows.Forms.Label();
            this.lblSN = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timMonitorProcess = new System.Windows.Forms.Timer(this.components);
            this.btnDebug = new System.Windows.Forms.Button();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.btnFlashIOBOARD = new System.Windows.Forms.Button();
            this.btnRLogsIOBOARD = new System.Windows.Forms.Button();
            this.btnChkIOBOARD = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.btnCaddOpts = new System.Windows.Forms.Button();
            this.btnPML = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnRLogsCashAccept = new System.Windows.Forms.Button();
            this.btnChkCashAccept = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnRLogsBNR = new System.Windows.Forms.Button();
            this.btnChkBNR = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnRLogsBCR = new System.Windows.Forms.Button();
            this.btnChkBCR = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.btnFlashRECPRINTER = new System.Windows.Forms.Button();
            this.btnRLogsRECPRINTER = new System.Windows.Forms.Button();
            this.btnActivateNCRLOADER2 = new System.Windows.Forms.Button();
            this.btnChkRECPRINTER = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnFlashPRINTER = new System.Windows.Forms.Button();
            this.btnRLogsPRINTER = new System.Windows.Forms.Button();
            this.btnActiveNCRLOADER = new System.Windows.Forms.Button();
            this.btnChkPRINTER = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnRLogsCR5000 = new System.Windows.Forms.Button();
            this.btnChkCR5000 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnRLogsGSR50 = new System.Windows.Forms.Button();
            this.btnChkGSR50 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.btnCalibrate = new System.Windows.Forms.Button();
            this.btnRLogsSCALE = new System.Windows.Forms.Button();
            this.btnChkSCALE = new System.Windows.Forms.Button();
            this.lblProgress = new System.Windows.Forms.Label();
            this.btnEboxTest = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel_4 = new System.Windows.Forms.Panel();
            this.panel_2 = new System.Windows.Forms.Panel();
            this.panel_1 = new System.Windows.Forms.Panel();
            this.panel_3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblRunning = new System.Windows.Forms.Label();
            this.dgvDiagnosticPendings = new System.Windows.Forms.DataGridView();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.timerBeep = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFailures)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogs)).BeginInit();
            this.tabPage10.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiagnosticPendings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // dgvFailures
            // 
            this.dgvFailures.AllowUserToAddRows = false;
            this.dgvFailures.AllowUserToDeleteRows = false;
            this.dgvFailures.AllowUserToResizeColumns = false;
            this.dgvFailures.AllowUserToResizeRows = false;
            this.dgvFailures.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFailures.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFailures.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFailures.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PassFail});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFailures.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvFailures.Location = new System.Drawing.Point(17, 209);
            this.dgvFailures.Name = "dgvFailures";
            this.dgvFailures.RowTemplate.Height = 28;
            this.dgvFailures.Size = new System.Drawing.Size(1440, 531);
            this.dgvFailures.TabIndex = 1;
            this.dgvFailures.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFailures_CellContentClick);
            this.dgvFailures.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFailures_CellDoubleClick);
            // 
            // PassFail
            // 
            this.PassFail.HeaderText = "Status";
            this.PassFail.Name = "PassFail";
            this.PassFail.Width = 60;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 172);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Eventos:";
            // 
            // btnAnalizar
            // 
            this.btnAnalizar.Location = new System.Drawing.Point(1157, 752);
            this.btnAnalizar.Name = "btnAnalizar";
            this.btnAnalizar.Size = new System.Drawing.Size(150, 70);
            this.btnAnalizar.TabIndex = 4;
            this.btnAnalizar.Text = "Paso 3: CADD Checker";
            this.btnAnalizar.UseVisualStyleBackColor = true;
            this.btnAnalizar.Click += new System.EventHandler(this.btnAnalizar_Click);
            // 
            // btnContinuar
            // 
            this.btnContinuar.Enabled = false;
            this.btnContinuar.Location = new System.Drawing.Point(1315, 752);
            this.btnContinuar.Name = "btnContinuar";
            this.btnContinuar.Size = new System.Drawing.Size(150, 70);
            this.btnContinuar.TabIndex = 5;
            this.btnContinuar.Text = "Continuar";
            this.btnContinuar.UseVisualStyleBackColor = true;
            this.btnContinuar.Click += new System.EventHandler(this.btnContinuar_Click);
            // 
            // btnCadd
            // 
            this.btnCadd.Enabled = false;
            this.btnCadd.Location = new System.Drawing.Point(4, 997);
            this.btnCadd.Name = "btnCadd";
            this.btnCadd.Size = new System.Drawing.Size(113, 85);
            this.btnCadd.TabIndex = 6;
            this.btnCadd.Text = "Cadd RE-RUN";
            this.btnCadd.UseVisualStyleBackColor = true;
            this.btnCadd.Click += new System.EventHandler(this.btnCadd_Click);
            // 
            // dgvLogs
            // 
            this.dgvLogs.AllowUserToAddRows = false;
            this.dgvLogs.AllowUserToDeleteRows = false;
            this.dgvLogs.AllowUserToResizeColumns = false;
            this.dgvLogs.AllowUserToResizeRows = false;
            this.dgvLogs.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLogs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLogs.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvLogs.Location = new System.Drawing.Point(13, 790);
            this.dgvLogs.Name = "dgvLogs";
            this.dgvLogs.RowTemplate.Height = 28;
            this.dgvLogs.Size = new System.Drawing.Size(651, 193);
            this.dgvLogs.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 760);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "En proceso:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(259, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "CADD-ANALISIS";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.Location = new System.Drawing.Point(272, 77);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(69, 17);
            this.lblVersion.TabIndex = 10;
            this.lblVersion.Text = "VERSION";
            // 
            // btnUSBChecker
            // 
            this.btnUSBChecker.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUSBChecker.Location = new System.Drawing.Point(1001, 752);
            this.btnUSBChecker.Name = "btnUSBChecker";
            this.btnUSBChecker.Size = new System.Drawing.Size(150, 70);
            this.btnUSBChecker.TabIndex = 12;
            this.btnUSBChecker.Text = "Paso 2: Usb Checker";
            this.btnUSBChecker.UseVisualStyleBackColor = false;
            this.btnUSBChecker.Click += new System.EventHandler(this.btnUSBChecker_Click);
            // 
            // lblTracer
            // 
            this.lblTracer.AutoSize = true;
            this.lblTracer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTracer.Location = new System.Drawing.Point(1002, 121);
            this.lblTracer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTracer.Name = "lblTracer";
            this.lblTracer.Size = new System.Drawing.Size(82, 20);
            this.lblTracer.TabIndex = 13;
            this.lblTracer.Text = "TRACER:";
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClass.Location = new System.Drawing.Point(1266, 121);
            this.lblClass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(69, 20);
            this.lblClass.TabIndex = 14;
            this.lblClass.Text = "CLASS:";
            // 
            // lblMC
            // 
            this.lblMC.AutoSize = true;
            this.lblMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMC.Location = new System.Drawing.Point(1266, 149);
            this.lblMC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMC.Name = "lblMC";
            this.lblMC.Size = new System.Drawing.Size(40, 20);
            this.lblMC.TabIndex = 15;
            this.lblMC.Text = "MC:";
            // 
            // lblSN
            // 
            this.lblSN.AutoSize = true;
            this.lblSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSN.Location = new System.Drawing.Point(1001, 149);
            this.lblSN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSN.Name = "lblSN";
            this.lblSN.Size = new System.Drawing.Size(151, 20);
            this.lblSN.TabIndex = 16;
            this.lblSN.Text = "SERIAL NUMBER:";
            // 
            // timer1
            // 
            this.timer1.Interval = 15000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timMonitorProcess
            // 
            this.timMonitorProcess.Interval = 150;
            this.timMonitorProcess.Tick += new System.EventHandler(this.timMonitorProcess_Tick);
            // 
            // btnDebug
            // 
            this.btnDebug.Location = new System.Drawing.Point(242, 997);
            this.btnDebug.Name = "btnDebug";
            this.btnDebug.Size = new System.Drawing.Size(113, 85);
            this.btnDebug.TabIndex = 18;
            this.btnDebug.Text = "Get diag files";
            this.btnDebug.UseVisualStyleBackColor = true;
            this.btnDebug.Click += new System.EventHandler(this.btnDebug_Click);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.btnFlashIOBOARD);
            this.tabPage10.Controls.Add(this.btnRLogsIOBOARD);
            this.tabPage10.Controls.Add(this.btnChkIOBOARD);
            this.tabPage10.Location = new System.Drawing.Point(4, 44);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(328, 75);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "IO BOARD";
            // 
            // btnFlashIOBOARD
            // 
            this.btnFlashIOBOARD.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnFlashIOBOARD.Location = new System.Drawing.Point(112, 6);
            this.btnFlashIOBOARD.Name = "btnFlashIOBOARD";
            this.btnFlashIOBOARD.Size = new System.Drawing.Size(100, 60);
            this.btnFlashIOBOARD.TabIndex = 22;
            this.btnFlashIOBOARD.Text = "Flash Main  Firmware";
            this.btnFlashIOBOARD.UseVisualStyleBackColor = false;
            this.btnFlashIOBOARD.Click += new System.EventHandler(this.btnFlashIOBOARD_Click);
            // 
            // btnRLogsIOBOARD
            // 
            this.btnRLogsIOBOARD.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsIOBOARD.Location = new System.Drawing.Point(218, 6);
            this.btnRLogsIOBOARD.Name = "btnRLogsIOBOARD";
            this.btnRLogsIOBOARD.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsIOBOARD.TabIndex = 21;
            this.btnRLogsIOBOARD.Text = "Review Logs";
            this.btnRLogsIOBOARD.UseVisualStyleBackColor = false;
            this.btnRLogsIOBOARD.Click += new System.EventHandler(this.btnRLogsIOBOARD_Click);
            // 
            // btnChkIOBOARD
            // 
            this.btnChkIOBOARD.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkIOBOARD.Location = new System.Drawing.Point(6, 6);
            this.btnChkIOBOARD.Name = "btnChkIOBOARD";
            this.btnChkIOBOARD.Size = new System.Drawing.Size(100, 60);
            this.btnChkIOBOARD.TabIndex = 16;
            this.btnChkIOBOARD.Text = "Chkhealth";
            this.btnChkIOBOARD.UseVisualStyleBackColor = false;
            this.btnChkIOBOARD.Click += new System.EventHandler(this.btnChkIOBOARD_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.btnCaddOpts);
            this.tabPage8.Location = new System.Drawing.Point(4, 44);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(328, 75);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "PML";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // btnCaddOpts
            // 
            this.btnCaddOpts.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCaddOpts.Location = new System.Drawing.Point(6, 6);
            this.btnCaddOpts.Name = "btnCaddOpts";
            this.btnCaddOpts.Size = new System.Drawing.Size(100, 60);
            this.btnCaddOpts.TabIndex = 22;
            this.btnCaddOpts.Text = "CADDOPTS.001";
            this.btnCaddOpts.UseVisualStyleBackColor = false;
            this.btnCaddOpts.Click += new System.EventHandler(this.btnCaddOpts_Click);
            // 
            // btnPML
            // 
            this.btnPML.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPML.Location = new System.Drawing.Point(123, 997);
            this.btnPML.Name = "btnPML";
            this.btnPML.Size = new System.Drawing.Size(113, 85);
            this.btnPML.TabIndex = 21;
            this.btnPML.Text = "Open PML";
            this.btnPML.UseVisualStyleBackColor = false;
            this.btnPML.Click += new System.EventHandler(this.btnPML_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnRLogsCashAccept);
            this.tabPage6.Controls.Add(this.btnChkCashAccept);
            this.tabPage6.Location = new System.Drawing.Point(4, 44);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(328, 75);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "CASH ACCEPTOR";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // btnRLogsCashAccept
            // 
            this.btnRLogsCashAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsCashAccept.Location = new System.Drawing.Point(112, 6);
            this.btnRLogsCashAccept.Name = "btnRLogsCashAccept";
            this.btnRLogsCashAccept.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsCashAccept.TabIndex = 20;
            this.btnRLogsCashAccept.Text = "Review Logs";
            this.btnRLogsCashAccept.UseVisualStyleBackColor = false;
            this.btnRLogsCashAccept.Click += new System.EventHandler(this.btnRLogsCashAccept_Click);
            // 
            // btnChkCashAccept
            // 
            this.btnChkCashAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkCashAccept.Location = new System.Drawing.Point(6, 6);
            this.btnChkCashAccept.Name = "btnChkCashAccept";
            this.btnChkCashAccept.Size = new System.Drawing.Size(100, 60);
            this.btnChkCashAccept.TabIndex = 17;
            this.btnChkCashAccept.Text = "Chkhealth";
            this.btnChkCashAccept.UseVisualStyleBackColor = false;
            this.btnChkCashAccept.Click += new System.EventHandler(this.btnChkCashAccept_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPage5.Controls.Add(this.btnRLogsBNR);
            this.tabPage5.Controls.Add(this.btnChkBNR);
            this.tabPage5.Location = new System.Drawing.Point(4, 44);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(328, 75);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "MEI-BNR";
            // 
            // btnRLogsBNR
            // 
            this.btnRLogsBNR.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsBNR.Location = new System.Drawing.Point(112, 6);
            this.btnRLogsBNR.Name = "btnRLogsBNR";
            this.btnRLogsBNR.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsBNR.TabIndex = 20;
            this.btnRLogsBNR.Text = "Review Logs";
            this.btnRLogsBNR.UseVisualStyleBackColor = false;
            this.btnRLogsBNR.Click += new System.EventHandler(this.btnRLogsBNR_Click);
            // 
            // btnChkBNR
            // 
            this.btnChkBNR.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkBNR.Location = new System.Drawing.Point(6, 6);
            this.btnChkBNR.Name = "btnChkBNR";
            this.btnChkBNR.Size = new System.Drawing.Size(100, 60);
            this.btnChkBNR.TabIndex = 17;
            this.btnChkBNR.Text = "Chkhealth";
            this.btnChkBNR.UseVisualStyleBackColor = false;
            this.btnChkBNR.Click += new System.EventHandler(this.btnChkBNR_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnRLogsBCR);
            this.tabPage4.Controls.Add(this.btnChkBCR);
            this.tabPage4.Location = new System.Drawing.Point(4, 44);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(328, 75);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "BCR";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnRLogsBCR
            // 
            this.btnRLogsBCR.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsBCR.Location = new System.Drawing.Point(114, 6);
            this.btnRLogsBCR.Name = "btnRLogsBCR";
            this.btnRLogsBCR.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsBCR.TabIndex = 20;
            this.btnRLogsBCR.Text = "Review Logs";
            this.btnRLogsBCR.UseVisualStyleBackColor = false;
            this.btnRLogsBCR.Click += new System.EventHandler(this.btnRLogsBCR_Click);
            // 
            // btnChkBCR
            // 
            this.btnChkBCR.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkBCR.Location = new System.Drawing.Point(6, 6);
            this.btnChkBCR.Name = "btnChkBCR";
            this.btnChkBCR.Size = new System.Drawing.Size(100, 60);
            this.btnChkBCR.TabIndex = 17;
            this.btnChkBCR.Text = "Chkhealth";
            this.btnChkBCR.UseVisualStyleBackColor = false;
            this.btnChkBCR.Click += new System.EventHandler(this.btnChkBCR_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPage9.Controls.Add(this.btnFlashRECPRINTER);
            this.tabPage9.Controls.Add(this.btnRLogsRECPRINTER);
            this.tabPage9.Controls.Add(this.btnActivateNCRLOADER2);
            this.tabPage9.Controls.Add(this.btnChkRECPRINTER);
            this.tabPage9.Location = new System.Drawing.Point(4, 44);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(328, 75);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "REC PRINTER";
            // 
            // btnFlashRECPRINTER
            // 
            this.btnFlashRECPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnFlashRECPRINTER.Location = new System.Drawing.Point(323, 6);
            this.btnFlashRECPRINTER.Name = "btnFlashRECPRINTER";
            this.btnFlashRECPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnFlashRECPRINTER.TabIndex = 24;
            this.btnFlashRECPRINTER.Text = "Flash Main  Firmware";
            this.btnFlashRECPRINTER.UseVisualStyleBackColor = false;
            this.btnFlashRECPRINTER.Click += new System.EventHandler(this.btnFlashRECPRINTER_Click);
            // 
            // btnRLogsRECPRINTER
            // 
            this.btnRLogsRECPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsRECPRINTER.Location = new System.Drawing.Point(112, 6);
            this.btnRLogsRECPRINTER.Name = "btnRLogsRECPRINTER";
            this.btnRLogsRECPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsRECPRINTER.TabIndex = 23;
            this.btnRLogsRECPRINTER.Text = "Review Logs";
            this.btnRLogsRECPRINTER.UseVisualStyleBackColor = false;
            this.btnRLogsRECPRINTER.Click += new System.EventHandler(this.btnRLogsRECPRINTER_Click);
            // 
            // btnActivateNCRLOADER2
            // 
            this.btnActivateNCRLOADER2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnActivateNCRLOADER2.Location = new System.Drawing.Point(217, 6);
            this.btnActivateNCRLOADER2.Name = "btnActivateNCRLOADER2";
            this.btnActivateNCRLOADER2.Size = new System.Drawing.Size(100, 60);
            this.btnActivateNCRLOADER2.TabIndex = 22;
            this.btnActivateNCRLOADER2.Text = "Activate NCR_Loader";
            this.btnActivateNCRLOADER2.UseVisualStyleBackColor = false;
            this.btnActivateNCRLOADER2.Click += new System.EventHandler(this.btnActivateNCRLOADER2_Click);
            // 
            // btnChkRECPRINTER
            // 
            this.btnChkRECPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkRECPRINTER.Location = new System.Drawing.Point(6, 6);
            this.btnChkRECPRINTER.Name = "btnChkRECPRINTER";
            this.btnChkRECPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnChkRECPRINTER.TabIndex = 21;
            this.btnChkRECPRINTER.Text = "Chkhealth";
            this.btnChkRECPRINTER.UseVisualStyleBackColor = false;
            this.btnChkRECPRINTER.Click += new System.EventHandler(this.btnChkRECPRINTER_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnFlashPRINTER);
            this.tabPage3.Controls.Add(this.btnRLogsPRINTER);
            this.tabPage3.Controls.Add(this.btnActiveNCRLOADER);
            this.tabPage3.Controls.Add(this.btnChkPRINTER);
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(328, 75);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "PRINTER";
            // 
            // btnFlashPRINTER
            // 
            this.btnFlashPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnFlashPRINTER.Location = new System.Drawing.Point(112, 6);
            this.btnFlashPRINTER.Name = "btnFlashPRINTER";
            this.btnFlashPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnFlashPRINTER.TabIndex = 20;
            this.btnFlashPRINTER.Text = "Flash Main  Firmware";
            this.btnFlashPRINTER.UseVisualStyleBackColor = false;
            this.btnFlashPRINTER.Click += new System.EventHandler(this.btnFlashPRINTER_Click);
            // 
            // btnRLogsPRINTER
            // 
            this.btnRLogsPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsPRINTER.Location = new System.Drawing.Point(324, 6);
            this.btnRLogsPRINTER.Name = "btnRLogsPRINTER";
            this.btnRLogsPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsPRINTER.TabIndex = 19;
            this.btnRLogsPRINTER.Text = "Review Logs";
            this.btnRLogsPRINTER.UseVisualStyleBackColor = false;
            this.btnRLogsPRINTER.Click += new System.EventHandler(this.btnRLogsPRINTER_Click);
            // 
            // btnActiveNCRLOADER
            // 
            this.btnActiveNCRLOADER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnActiveNCRLOADER.Location = new System.Drawing.Point(218, 6);
            this.btnActiveNCRLOADER.Name = "btnActiveNCRLOADER";
            this.btnActiveNCRLOADER.Size = new System.Drawing.Size(100, 60);
            this.btnActiveNCRLOADER.TabIndex = 18;
            this.btnActiveNCRLOADER.Text = "Activate NCR_Loader";
            this.btnActiveNCRLOADER.UseVisualStyleBackColor = false;
            this.btnActiveNCRLOADER.Click += new System.EventHandler(this.btnActiveNCRLOADER_Click);
            // 
            // btnChkPRINTER
            // 
            this.btnChkPRINTER.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkPRINTER.Location = new System.Drawing.Point(6, 6);
            this.btnChkPRINTER.Name = "btnChkPRINTER";
            this.btnChkPRINTER.Size = new System.Drawing.Size(100, 60);
            this.btnChkPRINTER.TabIndex = 17;
            this.btnChkPRINTER.Text = "Chkhealth";
            this.btnChkPRINTER.UseVisualStyleBackColor = false;
            this.btnChkPRINTER.Click += new System.EventHandler(this.btnChkPRINTER_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPage2.Controls.Add(this.btnRLogsCR5000);
            this.tabPage2.Controls.Add(this.btnChkCR5000);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(328, 75);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "CR5000";
            // 
            // btnRLogsCR5000
            // 
            this.btnRLogsCR5000.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsCR5000.Location = new System.Drawing.Point(112, 6);
            this.btnRLogsCR5000.Name = "btnRLogsCR5000";
            this.btnRLogsCR5000.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsCR5000.TabIndex = 21;
            this.btnRLogsCR5000.Text = "Review Logs";
            this.btnRLogsCR5000.UseVisualStyleBackColor = false;
            this.btnRLogsCR5000.Click += new System.EventHandler(this.btnRLogsCR5000_Click);
            // 
            // btnChkCR5000
            // 
            this.btnChkCR5000.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkCR5000.Location = new System.Drawing.Point(6, 6);
            this.btnChkCR5000.Name = "btnChkCR5000";
            this.btnChkCR5000.Size = new System.Drawing.Size(100, 60);
            this.btnChkCR5000.TabIndex = 20;
            this.btnChkCR5000.Text = "Chkhealth";
            this.btnChkCR5000.UseVisualStyleBackColor = false;
            this.btnChkCR5000.Click += new System.EventHandler(this.btnChkCR5000_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnRLogsGSR50);
            this.tabPage1.Controls.Add(this.btnChkGSR50);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(328, 75);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "GSR50";
            // 
            // btnRLogsGSR50
            // 
            this.btnRLogsGSR50.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsGSR50.Location = new System.Drawing.Point(112, 6);
            this.btnRLogsGSR50.Name = "btnRLogsGSR50";
            this.btnRLogsGSR50.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsGSR50.TabIndex = 20;
            this.btnRLogsGSR50.Text = "Review Logs";
            this.btnRLogsGSR50.UseVisualStyleBackColor = false;
            this.btnRLogsGSR50.Click += new System.EventHandler(this.btnRLogsGSR50_Click);
            // 
            // btnChkGSR50
            // 
            this.btnChkGSR50.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkGSR50.Location = new System.Drawing.Point(6, 6);
            this.btnChkGSR50.Name = "btnChkGSR50";
            this.btnChkGSR50.Size = new System.Drawing.Size(100, 60);
            this.btnChkGSR50.TabIndex = 15;
            this.btnChkGSR50.Text = "Chkhealth";
            this.btnChkGSR50.UseVisualStyleBackColor = false;
            this.btnChkGSR50.Click += new System.EventHandler(this.btnChkGSR50_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.ItemSize = new System.Drawing.Size(144, 40);
            this.tabControl1.Location = new System.Drawing.Point(367, 997);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(336, 123);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 17;
            this.tabControl1.Visible = false;
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPage12.Controls.Add(this.btnCalibrate);
            this.tabPage12.Controls.Add(this.btnRLogsSCALE);
            this.tabPage12.Controls.Add(this.btnChkSCALE);
            this.tabPage12.Location = new System.Drawing.Point(4, 44);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(328, 75);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "SCALE";
            // 
            // btnCalibrate
            // 
            this.btnCalibrate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCalibrate.Location = new System.Drawing.Point(112, 6);
            this.btnCalibrate.Name = "btnCalibrate";
            this.btnCalibrate.Size = new System.Drawing.Size(100, 60);
            this.btnCalibrate.TabIndex = 24;
            this.btnCalibrate.Text = "Calibrate";
            this.btnCalibrate.UseVisualStyleBackColor = false;
            this.btnCalibrate.Click += new System.EventHandler(this.btnCalibrate_Click);
            // 
            // btnRLogsSCALE
            // 
            this.btnRLogsSCALE.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRLogsSCALE.Location = new System.Drawing.Point(218, 6);
            this.btnRLogsSCALE.Name = "btnRLogsSCALE";
            this.btnRLogsSCALE.Size = new System.Drawing.Size(100, 60);
            this.btnRLogsSCALE.TabIndex = 23;
            this.btnRLogsSCALE.Text = "Review Logs";
            this.btnRLogsSCALE.UseVisualStyleBackColor = false;
            this.btnRLogsSCALE.Click += new System.EventHandler(this.btnRLogsSCALE_Click);
            // 
            // btnChkSCALE
            // 
            this.btnChkSCALE.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChkSCALE.Location = new System.Drawing.Point(6, 6);
            this.btnChkSCALE.Name = "btnChkSCALE";
            this.btnChkSCALE.Size = new System.Drawing.Size(100, 60);
            this.btnChkSCALE.TabIndex = 22;
            this.btnChkSCALE.Text = "Chkhealth";
            this.btnChkSCALE.UseVisualStyleBackColor = false;
            this.btnChkSCALE.Click += new System.EventHandler(this.btnChkSCALE_Click);
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgress.Location = new System.Drawing.Point(1403, 831);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(53, 37);
            this.lblProgress.TabIndex = 19;
            this.lblProgress.Text = "0%";
            // 
            // btnEboxTest
            // 
            this.btnEboxTest.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnEboxTest.Location = new System.Drawing.Point(845, 752);
            this.btnEboxTest.Name = "btnEboxTest";
            this.btnEboxTest.Size = new System.Drawing.Size(150, 70);
            this.btnEboxTest.TabIndex = 22;
            this.btnEboxTest.Text = "Paso 1: CORE Test ";
            this.btnEboxTest.UseVisualStyleBackColor = false;
            this.btnEboxTest.Click += new System.EventHandler(this.btnEboxTest_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Location = new System.Drawing.Point(-2, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1562, 70);
            this.panel1.TabIndex = 23;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(1389, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 34;
            this.button1.Text = "?";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.Color.Black;
            this.btnMinimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMinimize.Location = new System.Drawing.Point(1447, 14);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(50, 50);
            this.btnMinimize.TabIndex = 33;
            this.btnMinimize.Text = "_";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(1505, 12);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 50);
            this.btnExit.TabIndex = 32;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel_4
            // 
            this.panel_4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_4.Location = new System.Drawing.Point(1455, 208);
            this.panel_4.Name = "panel_4";
            this.panel_4.Size = new System.Drawing.Size(10, 534);
            this.panel_4.TabIndex = 24;
            // 
            // panel_2
            // 
            this.panel_2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_2.Location = new System.Drawing.Point(13, 209);
            this.panel_2.Name = "panel_2";
            this.panel_2.Size = new System.Drawing.Size(10, 534);
            this.panel_2.TabIndex = 25;
            // 
            // panel_1
            // 
            this.panel_1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_1.Location = new System.Drawing.Point(12, 200);
            this.panel_1.Name = "panel_1";
            this.panel_1.Size = new System.Drawing.Size(1452, 10);
            this.panel_1.TabIndex = 26;
            // 
            // panel_3
            // 
            this.panel_3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_3.Location = new System.Drawing.Point(14, 738);
            this.panel_3.Name = "panel_3";
            this.panel_3.Size = new System.Drawing.Size(1451, 10);
            this.panel_3.TabIndex = 27;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel6.Location = new System.Drawing.Point(4, 790);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 193);
            this.panel6.TabIndex = 26;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel7.Location = new System.Drawing.Point(664, 790);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 193);
            this.panel7.TabIndex = 27;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel8.Location = new System.Drawing.Point(4, 783);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(670, 10);
            this.panel8.TabIndex = 28;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel9.Location = new System.Drawing.Point(4, 981);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(670, 10);
            this.panel9.TabIndex = 29;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel10.Location = new System.Drawing.Point(985, 76);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(476, 10);
            this.panel10.TabIndex = 27;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel11.Location = new System.Drawing.Point(985, 77);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(10, 107);
            this.panel11.TabIndex = 28;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel12.Location = new System.Drawing.Point(985, 183);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(476, 10);
            this.panel12.TabIndex = 28;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel13.Location = new System.Drawing.Point(1453, 76);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(10, 117);
            this.panel13.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1000, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "UNIT INFO:";
            // 
            // lblRunning
            // 
            this.lblRunning.AutoSize = true;
            this.lblRunning.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunning.Location = new System.Drawing.Point(1264, 831);
            this.lblRunning.Name = "lblRunning";
            this.lblRunning.Size = new System.Drawing.Size(142, 37);
            this.lblRunning.TabIndex = 31;
            this.lblRunning.Text = "Running...";
            // 
            // dgvDiagnosticPendings
            // 
            this.dgvDiagnosticPendings.AllowUserToAddRows = false;
            this.dgvDiagnosticPendings.AllowUserToDeleteRows = false;
            this.dgvDiagnosticPendings.AllowUserToResizeColumns = false;
            this.dgvDiagnosticPendings.AllowUserToResizeRows = false;
            this.dgvDiagnosticPendings.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDiagnosticPendings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvDiagnosticPendings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDiagnosticPendings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewImageColumn1});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDiagnosticPendings.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvDiagnosticPendings.Location = new System.Drawing.Point(712, 918);
            this.dgvDiagnosticPendings.Name = "dgvDiagnosticPendings";
            this.dgvDiagnosticPendings.RowTemplate.Height = 28;
            this.dgvDiagnosticPendings.Size = new System.Drawing.Size(753, 208);
            this.dgvDiagnosticPendings.TabIndex = 32;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "Status";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Width = 60;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(708, 886);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(188, 20);
            this.label5.TabIndex = 33;
            this.label5.Text = "Diagnosticos pendientes:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Location = new System.Drawing.Point(1455, 917);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 210);
            this.panel2.TabIndex = 25;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Location = new System.Drawing.Point(709, 909);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(756, 11);
            this.panel3.TabIndex = 28;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.Location = new System.Drawing.Point(826, 1120);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(640, 10);
            this.panel4.TabIndex = 29;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.Location = new System.Drawing.Point(709, 909);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 223);
            this.panel5.TabIndex = 34;
            // 
            // timerBeep
            // 
            this.timerBeep.Interval = 5000;
            this.timerBeep.Tick += new System.EventHandler(this.timerBeep_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::CADD_ANALISIS.Properties.Resources.exclamation_mark;
            this.pictureBox1.Location = new System.Drawing.Point(859, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1558, 1094);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnPML);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgvDiagnosticPendings);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblRunning);
            this.Controls.Add(this.panel_2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel_3);
            this.Controls.Add(this.panel_1);
            this.Controls.Add(this.panel_4);
            this.Controls.Add(this.btnEboxTest);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.btnDebug);
            this.Controls.Add(this.lblSN);
            this.Controls.Add(this.lblMC);
            this.Controls.Add(this.lblClass);
            this.Controls.Add(this.lblTracer);
            this.Controls.Add(this.btnUSBChecker);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvLogs);
            this.Controls.Add(this.btnCadd);
            this.Controls.Add(this.btnContinuar);
            this.Controls.Add(this.btnAnalizar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvFailures);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CADD-UI monitor Jabil";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFailures)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogs)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiagnosticPendings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.DataGridView dgvFailures;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnAnalizar;
        private System.Windows.Forms.Button btnContinuar;
        private System.Windows.Forms.Button btnCadd;
        private System.Windows.Forms.DataGridView dgvLogs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnUSBChecker;
        private System.Windows.Forms.DataGridViewImageColumn PassFail;
        private System.Windows.Forms.Label lblTracer;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblMC;
        private System.Windows.Forms.Label lblSN;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timMonitorProcess;
        private System.Windows.Forms.Button btnDebug;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Button btnRLogsIOBOARD;
        private System.Windows.Forms.Button btnChkIOBOARD;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button btnPML;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnRLogsCashAccept;
        private System.Windows.Forms.Button btnChkCashAccept;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnRLogsBNR;
        private System.Windows.Forms.Button btnChkBNR;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnRLogsBCR;
        private System.Windows.Forms.Button btnChkBCR;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button btnFlashRECPRINTER;
        private System.Windows.Forms.Button btnRLogsRECPRINTER;
        private System.Windows.Forms.Button btnActivateNCRLOADER2;
        private System.Windows.Forms.Button btnChkRECPRINTER;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnFlashPRINTER;
        private System.Windows.Forms.Button btnRLogsPRINTER;
        private System.Windows.Forms.Button btnActiveNCRLOADER;
        private System.Windows.Forms.Button btnChkPRINTER;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnRLogsCR5000;
        private System.Windows.Forms.Button btnChkCR5000;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnRLogsGSR50;
        private System.Windows.Forms.Button btnChkGSR50;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.Button btnRLogsSCALE;
        private System.Windows.Forms.Button btnChkSCALE;
        private System.Windows.Forms.Button btnCalibrate;
        private System.Windows.Forms.Button btnFlashIOBOARD;
        private System.Windows.Forms.Button btnCaddOpts;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.Button btnEboxTest;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_4;
        private System.Windows.Forms.Panel panel_2;
        private System.Windows.Forms.Panel panel_1;
        private System.Windows.Forms.Panel panel_3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblRunning;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.DataGridView dgvDiagnosticPendings;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Timer timerBeep;
    }
}


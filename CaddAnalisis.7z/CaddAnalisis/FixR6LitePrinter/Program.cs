﻿using CADD_ANALISIS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace FixR6LitePrinter
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        static void Main()
        {
            try
            {
        
                bool result;
                string WindowsState = "FALSE"; //Variable para iniciar oculta la aplicacion
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                string _CustomImage = "CUSTOM_IMAGE";

                string[] _Args = Environment.GetCommandLineArgs(); //Lectura de argumentos de entrada
                

                if (_Args.Contains("CUSTOM_IMAGE"))
                {
                    Application.Run(new DebugMode());

                    goto END;
                }

                if (_Args.Contains("TRUE") || _Args.Contains("true") || _Args.Contains("True")) //Si los argumentos de entrada contienen un true aplicacion inicia visible top most
                {
                    WindowsState = "TRUE";
                    Application.Run(new Form1(WindowsState));
                }
                else
                {
                    Application.Run(new Form1(WindowsState)); //Aplicacion inicia con la propiedad visible en false
                }


                END: { };

            }

            catch (Exception ex)
            {
               
            }
          
           
        }      
    }
}

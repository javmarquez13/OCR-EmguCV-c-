﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CADD_ANALISIS
{
    public partial class DiagnosticFailures : Form
    {

        string DATE, TRACER, MODULENAME, DETAILS;

        public string DIAGNOSTICANDREPAIR { get; set; }
        public string USER { get; set; }
        public string SERIAL_NUMBER { get; set; }

        public DiagnosticFailures(string Date, string Tracer, string ModuleName, string Details)
        {
            InitializeComponent();
            txtDetails.Enabled = false;
            txtSerialNumber.Enabled = false;
            this.DIAGNOSTICANDREPAIR = null;
            this.USER = null;
            this.SERIAL_NUMBER = null;
            DATE = Date;
            TRACER = Tracer;
            MODULENAME = ModuleName;
            DETAILS = Details;

            lblDate.Text = DATE;
            lblTracer.Text = TRACER;
            lblModule.Text = MODULENAME;
            lblFailure.Text = DETAILS;
        }

        private void btnSelectUser_Click(object sender, EventArgs e)
        {
            if (cBoxUser.Text == "") return;
            USER = cBoxUser.Text + ":";
            txtDetails.Enabled = true;
            txtSerialNumber.Enabled = true;
        }

        private void btnContinuar_Click(object sender, EventArgs e)
        {
            DIAGNOSTICANDREPAIR = txtDetails.Text;
            SERIAL_NUMBER = txtSerialNumber.Text;
            if (cBoxUser.Text == "") return;
            if (txtDetails.Text == "") return;
            DialogResult = DialogResult.OK;
        }
    }
}

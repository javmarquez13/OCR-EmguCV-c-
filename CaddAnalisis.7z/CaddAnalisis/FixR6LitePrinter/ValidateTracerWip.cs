﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GetSerialClassMC;

namespace CADD_ANALISIS
{
    class ValidateTracerWip
    {
        public string WIPSCANNEDUNIT { get; set; }

        public ValidateTracerWip()
        {
            this.WIPSCANNEDUNIT = null;
        }

        GetSerialClassMC.GetSerialClassMC TracerInfo = new GetSerialClassMC.GetSerialClassMC();

        public void ValidateWip(string TRACER)
        {
            string WipScannedUnit = "";
            string Prefijo = "? UNITINFO 73";
            
            StreamReader _sReader = new StreamReader(@"c:\Mavis\" + TRACER + ".EJL");

            try
            {             
                while (!_sReader.EndOfStream)
                {
                    WipScannedUnit = _sReader.ReadLine();

                    if (WipScannedUnit.Contains(Prefijo))
                    {
                       WIPSCANNEDUNIT = WipScannedUnit.Substring(26, 11);
                       WIPSCANNEDUNIT = WIPSCANNEDUNIT.Replace('/', '-');
                    }
                }
            }
            catch (Exception ex)
            {
                _sReader.Close(); 
            }
            _sReader.Close();     
        }


        
    }
}

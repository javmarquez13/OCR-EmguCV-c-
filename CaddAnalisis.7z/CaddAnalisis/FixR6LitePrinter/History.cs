﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Data;

namespace CADD_ANALISIS
{
    class History //Esta clase genera los filesLogs .xml de los resultados de purebas.
    {
        StreamWriter _WriterLocal;
        StreamWriter _WriteServer;
        DataTable tableLOG;
        DataTable _tableXML;
        DataSet _ds;

        //string LOG = @"\\mxchim0pangea01\ssco_images\logs\";
        string LOG = @"\\mxchim0pangea01\diskbld\USBMapping\LogsSSCOs\";
        string LOGBK = @"\\mxchim0pangea01\SSCO_IMAGES\LOGS\USBChecker\";

        //string LOGCADD = @"\\mxchim0pangea01\diskbld\USBMapping\LogsSSCOsCADD\";
        string LOGCADD = @"\\mxchim0pangea01\SSCO_CADDChecker\";
        string LOGBKCADD = @"\\mxchim0pangea01\SSCO_IMAGES\LOGS\CADDChecker\";

        string LOGEBOX = @"\\mxchim0pangea01\SSCO_EBOXTest\";
        string LOGBKEBOX = @"\\mxchim0pangea01\SSCO_IMAGES\LOGS\EBOXTest\";

        string LOGSemaphore = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\xml\";


        string _ReportFileXML = @"c:\JABIL\";
        string _Server = @"\\mxchim0pangea01\Test_Docs\SSCO\Applications\logs\" + Environment.MachineName + ".txt"; 
        string _CustomFile = @"\\mxchim0pangea01\Test_Docs\SSCO\Applications\logs\";

        public void InsertFailure(DateTime DateTime, string UTT, string Module, string Comments) //Funcion vieja no se usa
        {
          // _WriterLocal = File.AppendText(_ReportFile);
            //_WriteServer = File.AppendText(_Server);
            try
            {
                //_WriterLocal.WriteLine(" * ****************************************FAILURE******************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine(DateTime.ToString().ToUpper());
                //_WriterLocal.WriteLine("UTT:" + UTT.ToUpper());
                //_WriterLocal.WriteLine("Module:" + Module.ToUpper());
                //_WriterLocal.WriteLine("Comentarios:" + Comments.ToUpper());
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("***********************************************************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.Close();
                //_WriteServer.WriteLine("*****************************************FAILURE******************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine(DateTime.ToString().ToUpper());
                //_WriteServer.WriteLine("UTT:" + UTT.ToUpper());
                //_WriteServer.WriteLine("Module:" + Module.ToUpper());
                //_WriteServer.WriteLine("Comentarios:" + Comments.ToUpper());
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("***********************************************************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.Close();
            }            
            catch (Exception ex)
            {
                
            }
        }

        public void EventCADD_ANALISIS(DateTime DateTime, string UTT, string AppMode, string Module, string Comments) //Funcion vieja no se usa
        {
           // _WriterLocal = File.AppendText(_ReportFile);
            //_WriteServer = File.AppendText(_Server);
            try
            {
                //_WriterLocal.WriteLine("***********************************************EVENT************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine(DateTime.ToString().ToUpper());
                //_WriterLocal.WriteLine("UTT: " + UTT.ToUpper());
                //_WriterLocal.WriteLine("AppMode: " + AppMode.ToUpper());
                //_WriterLocal.WriteLine("Module: " + Module.ToUpper());
                //_WriterLocal.WriteLine("Comentarios: " + Comments.ToUpper());
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("***********************************************************************************************************************");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.WriteLine("");
                //_WriterLocal.Close();
                //_WriteServer.WriteLine("***********************************************EVENT************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine(DateTime.ToString().ToUpper());
                //_WriteServer.WriteLine("UTT: " + UTT.ToUpper());
                //_WriteServer.WriteLine("AppMode: " + AppMode.ToUpper());
                //_WriterLocal.WriteLine("Module: " + Module.ToUpper());
                //_WriteServer.WriteLine("Comentarios: " + Comments.ToUpper());
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("***********************************************************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.Close();
            }
            catch (Exception ex)
            {

            }
        }

        public void EventCUSTOMOS(DateTime DateTime, string UTT, string CustomImage, string ImageInstalled) //Funcion vieja no se usa
        {
            //_WriteServer = File.AppendText(_CustomFile + Environment.MachineName + ".txt");
            try
            {
                //_WriteServer.WriteLine("***********************************************EVENT************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine(DateTime.ToString().ToUpper());
                //_WriteServer.WriteLine("UTT: " + UTT.ToUpper());
                //_WriteServer.WriteLine("Correct Image: " + CustomImage.ToUpper());
                //_WriteServer.WriteLine("Image installed: " + ImageInstalled);
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("***********************************************************************************************************************");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.WriteLine("");
                //_WriteServer.Close();
            }

            catch (Exception ex)
            {
                
            }
        }


        public void USBTable() //Funcion para la creacion de la tabla en memoria para la prueba USBChecker
        {
            tableLOG = new DataTable("USB_LOG");
            tableLOG.Columns.Add("DATE");
            tableLOG.Columns.Add("TRACER");
            tableLOG.Columns.Add("STATUS");
            tableLOG.Columns.Add("MODULE");
            tableLOG.Columns.Add("PIDVID");
            tableLOG.Columns.Add("COMMENTS");
        }

        public void CADDTable() //Funcion para la creacion de la tabla en memoria para la prueba CADDChecker
        {
            tableLOG = new DataTable("CADD_LOG");
            tableLOG.Columns.Add("DATE");
            tableLOG.Columns.Add("TRACER");
            tableLOG.Columns.Add("STATUS");
            tableLOG.Columns.Add("MODULE");
            tableLOG.Columns.Add("COMMENTS");
            tableLOG.Columns.Add("USER");
            tableLOG.Columns.Add("DIAGNOSTIC");
            tableLOG.Columns.Add("SERIALNUMBER");
        }

        public void EBOXTable() //Funcion para la creacion de la tabla en memoria para la prueba CADDChecker
        {
            tableLOG = new DataTable("EBOX_LOG");
            tableLOG.Columns.Add("DATE");
            tableLOG.Columns.Add("TRACER");
            tableLOG.Columns.Add("STATUS");
            tableLOG.Columns.Add("MODULE");
            tableLOG.Columns.Add("COMMENTS");
        }

        public void AddInfoTable(DateTime DATE, string TRACER, string STATUS, string MODULE, string PIDVID, string COMMENTS) //Funcion para agregar filas a la tabla en memoria USBChecker
        {       
            tableLOG.Rows.Add(DATE, TRACER, STATUS, MODULE, PIDVID, COMMENTS);
        }

        public void AddInfoCADDTable(DateTime DATE, string TRACER, string STATUS, string MODULE, string COMMENTS, string USER, string DIAGNOSTIC, string SERIALNUMBER) //Funcion para agregar filas a la tabla en memoria CADDChecker
        {       
            tableLOG.Rows.Add(DATE, TRACER, STATUS, MODULE, COMMENTS,USER, DIAGNOSTIC, SERIALNUMBER);
        }

        public void AddInfoEBOXTable(DateTime DATE, string TRACER, string STATUS, string MODULE, string COMMENTS) //Funcion para agregar filas a la tabla en memoria EBOXTest
        {
            tableLOG.Rows.Add(DATE, TRACER, STATUS, MODULE, COMMENTS);
        }


        public void CreateXML_START(string MODE, string TRACER) //Funcion para crear log file START.xml apartir de la tabla en memoria USBChecker 
        {
            string outputPath = "";
            outputPath = LOGBK + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            DataSet setXML = new DataSet(MODE);
            setXML.Tables.Add(tableLOG);
            string XML = setXML.GetXml();
            File.WriteAllText(LOG + TRACER + "_START" + ".XML", XML);
            File.WriteAllText(outputPath + TRACER + "_START" + ".XML", XML);
            setXML.Tables.Remove(tableLOG);
        }

        public void CreateXML_END(string MODE, string TRACER) //Funcion para crear log file END.xml apartir de la tabla en memoria USBChecker 
        {
            //Funcion para organizar archivos de backup por fecha y hora
            string outputPath = "";
            outputPath = LOGBK + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }
          
            DataSet setXML = new DataSet(MODE);
            setXML.Tables.Add(tableLOG);
            string XML = setXML.GetXml();
            File.WriteAllText(LOG + TRACER + "_END" + ".XML", XML);
            File.WriteAllText(outputPath + TRACER + "_END" + ".XML", XML);
            setXML.Tables.Remove(tableLOG);
        }

        public void CreateXMLCADD_START(string MODE, string TRACER) //Funcion para crear log file START.xml apartir de la tabla CADDChecker
        {
            //Funcion para organizar archivos de backup por fecha y hora
            string outputPath = "";
            outputPath = LOGBKCADD + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            DataSet setXML = new DataSet(MODE);
            setXML.Tables.Add(tableLOG);
            string XML = setXML.GetXml();
            File.WriteAllText(LOGCADD + TRACER + ".XML", XML);
            File.WriteAllText(outputPath + TRACER + "_FAIL" + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".XML", XML);
            setXML.Tables.Remove(tableLOG);
        }

        public void CreateXMLCADD_END(string MODE, string TRACER) //Funcion para crear log file END.xml apartir de la tabla CADDChecker
        {
            //Funcion para organizar archivos de backup por fecha y hora
            string outputPath = "";
            outputPath = LOGBKCADD + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            DataSet setXML = new DataSet(MODE);
            setXML.Tables.Add(tableLOG);
            string XML = setXML.GetXml();
            File.WriteAllText(LOGCADD + TRACER + ".XML", XML);
            File.WriteAllText(outputPath + TRACER + "_GOOD" + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".XML", XML);
            setXML.Tables.Remove(tableLOG);
        }


        public void CreateXML_EBOXTest(string MODE, string TRACER) //Funcion para crear log file xml apartir de la tabla EBOXTest
        {
            //Funcion para organizar archivos de backup por fecha y hora
            string outputPath = "";
            outputPath = LOGBKEBOX + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            DataSet setXML = new DataSet(MODE);
            setXML.Tables.Add(tableLOG);
            string XML = setXML.GetXml();
            File.WriteAllText(LOGEBOX + TRACER + ".XML", XML);
            File.WriteAllText(outputPath + TRACER + ".XML", XML);
            setXML.Tables.Remove(tableLOG);
        }

        public void XMLSSCOSem()
        {
            _tableXML = new DataTable("SEMAPHORE_SSCO");
            _tableXML.Columns.Add("DATE");
            _tableXML.Columns.Add("TRACER");
            _tableXML.Columns.Add("SLOT");
            _tableXML.Columns.Add("IPADRESS");
            _tableXML.Columns.Add("STATUS");
        }

        public void CreateXMLSem(DateTime DATE, string TRACER, string SLOT, string IPADRESS, string STATUS)
        {
            _tableXML.Rows.Add(DATE, TRACER, SLOT, IPADRESS, STATUS);

            _ds = new DataSet("SEMAPHORE");
            _ds.Tables.Add(_tableXML);
            string XML = _ds.GetXml();
            File.WriteAllText(LOG + TRACER + ".XML", XML);
            _ds.Tables.Remove(_tableXML);
        }
    }
}

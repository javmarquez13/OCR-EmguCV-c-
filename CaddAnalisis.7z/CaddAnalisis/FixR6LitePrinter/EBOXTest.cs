﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;
using System.Diagnostics;
using Microsoft.VisualBasic;
using Microsoft.Win32;
using System.IO;

namespace CADD_ANALISIS
{
    class EBOXTest
    {
        public ulong MEMORY_RAM { get; set; }
        public string CPU { get; set; }

        public EBOXTest()
        {
            this.MEMORY_RAM = 0;
            this.CPU = null;
        }


        //Win32_Processor
        string buildType;
        Microsoft.VisualBasic.Devices.ComputerInfo ComputerInfo = new Microsoft.VisualBasic.Devices.ComputerInfo();

        public void GetMemoryRam()
        {
            try
            {
                UInt64[] size = new UInt64[4];
                string[] slot = new string[4];

                for (int i = 0; i < 4; i++)
                {

                    try
                    {
                        string tag = i.ToString();
                        var ram = new ManagementObjectSearcher("Select * from WIN32_PhysicalMemory WHERE Tag LIKE 'Physical Memory " + tag + "'").Get().Cast<ManagementObject>().First();
                        size[i] = (UInt64)ram["Capacity"];
                        slot[i] = (string)ram["DeviceLocator"];
                    }
                    catch (Exception e)
                    {
                        size[i] = 0;
                        slot[i] = "unknown";
                    }
                }

                MEMORY_RAM = size[0] + size[1] + size[2] + size[3];

                //  MEMORY_RAM = ComputerInfo.TotalPhysicalMemory;    
                //RegistryKey Rkey = Registry.LocalMachine;
                //Rkey = Rkey.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
                //CPU = (string)Rkey.GetValue("ProcessorNameString");
       
            }
            catch(Exception ex)
            {
               
            }
          
        }

        public void CheckCPUType()
        {
            try
            {
                var result_cpu = new ManagementObjectSearcher("select * from Win32_Processor").Get().Cast<ManagementObject>().First();
                CPU = ((string)result_cpu["Name"]).ToLower();
            }
            catch (Exception ex)
            {
                CPU = ex.Message;
            }
           
        }


    }
}

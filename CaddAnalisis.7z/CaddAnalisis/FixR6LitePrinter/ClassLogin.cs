﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CADD_ANALISIS
{
    class ClassLogin
    {
        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        public static extern int LogonUser(string lpszUserName, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);
        public const int LOGON32_LOGON_INTERACTIVE = 2;
        public const int LOGON32_PROVIDER_DEFAULT = 0;
        IntPtr token = IntPtr.Zero;
        string JabilDomain = "corp.JABIL.ORG";

        private string sUser;
        private string sPassword;


        public ClassLogin()
        {
            sUser = "";
            sPassword = "";
        }

        public ClassLogin(string sUserName, string sPassword)
        {
            this.sUser =  sUserName;
            this.sPassword = sPassword;
        }

        public bool Logon()
        {
            if (LogonUser(this.sUser, System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName.ToString(), this.sPassword, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, ref token) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Logon(string sUserName, string sPassword)
        {
            if (LogonUser(sUserName, System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName.ToString(), sPassword, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, ref token) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
